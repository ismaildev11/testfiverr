
   <?php require './layout.php';?>
  

       
            <div class="main">
             
                <div class="h3 text-center  bg-info">Add Client</div> 
                <div class="newstudentmiddle" >
                         
                    
                
                           
                           <div class="row">
                               
                               <div class="col-12">
                                    
                                   
                                   <div class="form-group">
                                   <LABEL>First Name</LABEL><br/>
                                   <input id="firstname" style="border: 2px solid #1E90FF" type="text" name="firstname" value="" class=" form-control" maxlength="50" placeholder="Enter client first name"  autofocus required> 
                                 </div>
                              
                                   
                               </div>
                               <div class="col-12">
                                 <div class="form-group">
                                    <LABEL>Last Name</LABEL><br/>
      <input id="lastname" style="border: 2px solid #1E90FF" type="text" name="lastname" class=" form-control" maxlength="40" placeholder="Enter client last name" title="Enter client last name" autofocus required> 
                                 </div>
                                      
                                   
                               </div>
                               
                           </div>
                           <div class="row">
                               
                              <div class="form-group col-12">
                                   <LABEL>Phone Number</LABEL><br/>
                                    <input id="phonenumber" style="border: 2px solid #1E90FF" type="text" name="phonenumber" class=" form-control" maxlength="40" placeholder="Enter client phone number" title="Student mobile number input box" autofocus required> 
                                 </div>
                                   <div class="form-group col-12">
                                   
                                         <div class="form-group">
                                      
                                             
                                             <input type="text" value="<?php echo $_SESSION['username'] ;?>" class="bg-success" id="user" style="display: none;">
                                             <input type="submit" value="Save" class="bg-success" onclick="methodNewAdmission()">
                                         </div>
                                   </div>
                               
                           </div>
                        

                        
                  
                                          
                                
                           
                    <script>
function methodNewAdmission() 
{
 var fn=document.getElementById('firstname').value;
  var ln=document.getElementById('lastname').value;
  var  pn=document.getElementById('phonenumber').value;   
  var  user=document.getElementById('user').value;   
 
//alert();
  
        var xmlhttp = new XMLHttpRequest();
    //  xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.open("GET", "addClientsRequest.php?firstname="+fn+"&lastname="+ln+"&phonenumber="+pn+"&user="+user, true);
   
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState === 4 && this.status === 200) 
            {
                //document.getElementById("txtHint").innerHTML = this.responseText;
                if(this.responseText==1)
                {
                    var success="successfully Inserted";
                   // document.getElementById("myform").reset();
                   // document.getElementById("result").style.visibility="visible";
                    document.getElementById("resulttext").innerHTML = success;
                 document.getElementById('firstname').value="";
document.getElementById('lastname').value="";
  document.getElementById('phonenumber').value="";

 
                }
               // window.location.reload();
               // window.location.href = "./clients.php";
            }
            else
            {
                document.getElementById("resulttext").innerHTML = this.responseText;
            }
        };
    
}

function Load()
{
    afterFive();
   // alert();
}

    

</script>
                         </div>
                           
                           
                <div style="align-content: center">  <label class="text-success" id="resulttext"></label> </div>
         
                        
                        
                
                    
              
                        </div>
                


            
            
                  
            
            
        </body>
</html>