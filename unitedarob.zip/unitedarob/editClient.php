
       <script>

function Load()
{
    var xmlhttp=new XMLHttpRequest();
  
            xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("clientShow").innerHTML = this.responseText;
            }
        };
    
    xmlhttp.open("GET","clientName.php",true);
    xmlhttp.send();
    afterFive();
}
function onchangeClient(clientid)
{
   //alert(clientid);
        var xmlhttp=new XMLHttpRequest();
  
            xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
               // alert(this.responseText);
                var result= JSON.parse(this.responseText);
                //result.firstname;
           document.getElementById("id").value = result.id;
           document.getElementById("firstname").value = result.firstname;
           document.getElementById("lastname").value = result.lastname;
           document.getElementById("phonenumber").value = result.phonenumber;
            }
        };
    
    xmlhttp.open("GET","findClient.php?id="+clientid,true);
    xmlhttp.send();
}
function update() 
{
     var  user=document.getElementById('user').value;   
 var id=document.getElementById('id').value;
 var fn=document.getElementById('firstname').value;
  var ln=document.getElementById('lastname').value;
  var  pn=document.getElementById('phonenumber').value;   
 
//alert();
  
        var xmlhttp = new XMLHttpRequest();
    //  xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.open("GET", "updateClientsRequest.php?firstname="+fn+"&lastname="+ln+"&phonenumber="+pn+"&id="+id+"&user="+user, true);
//      xmlhttp.open("GET", "RequestCreateExamAndInsertmarks.php?class="+classSelected+"&batch="+batchSelected+"&group="+groupSelected+"&date="+examdate+"&Inputexamsubject="+subject+"&marks="+exammarks, true);

        
           
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState === 4 && this.status === 200) 
            {
                //document.getElementById("txtHint").innerHTML = this.responseText;
                if(this.responseText==1)
                {
                    var success="Successfully Updated";
                   // document.getElementById("myform").reset();
                   // document.getElementById("result").style.visibility="visible";
                   // document.getElementById("resulttext").innerHTML = success;
                    document.getElementById('firstname').value="";
document.getElementById('lastname').value="";
  document.getElementById('phonenumber').value="";
                    document.getElementById("resulttext").innerHTML = success;
                }
             
               // window.location.href = "./clients.php";
            }
            else
            {
               // alert(this.responseText);
            }
        };
    
}
function updateClient()
{
   //alert(clientid);
        var xmlhttp=new XMLHttpRequest();
  
            xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
               // alert(this.responseText);
                var result= JSON.parse(this.responseText);
                //result.firstname;
           document.getElementById("id").value = result.id;
           document.getElementById("firstname").value = result.firstname;
           document.getElementById("lastname").value = result.lastname;
           document.getElementById("phonenumber").value = result.phonenumber;
            }
        };
    
    xmlhttp.open("GET","findClient.php?id="+clientid,true);
    xmlhttp.send();
}

</script>
<?php require './layout.php';?>
  

       
            <div class="main">
                
                <div class="h3 text-center  bg-info">Edit Client</div> 
                <div class="newstudentmiddle" >
                    <div class="row">    
                         
                    <div class="col-12 mb-3 mt-3">    
                        <select style="width: 100%;font-size:20px; font-weight: bold" id="clientShow" onchange="onchangeClient(this.value)"></select>
                    </div>
                    </div>
                   
                           
                           <div class="row">
                               
                               <div class="col-12">
                                    
                                   
                                   <div class="form-group">
                                   <LABEL>First Name</LABEL><br/>
                                   <input id="id" style="display: none;"> 
                                   <input id="firstname" style="border: 2px solid #1E90FF" type="text" name="firstname" value="" class=" form-control" maxlength="50" placeholder="Enter client first name"  autofocus required> 
                                 </div>
                              
                                   
                               </div>
                               <div class="col-12">
                                 <div class="form-group">
                                    <LABEL>Last Name</LABEL><br/>
      <input id="lastname" style="border: 2px solid #1E90FF" type="text" name="lastname" class=" form-control" maxlength="40" placeholder="Enter client last name" title="Enter client last name" autofocus required> 
                                 </div>
                                      
                                   
                               </div>
                               
                           </div>
                           <div class="row">
                               
                              <div class="form-group col-12">
                                   <LABEL>Phone Number</LABEL><br/>
                                    <input id="phonenumber" style="border: 2px solid #1E90FF" type="text" name="phonenumber" class=" form-control" maxlength="40" placeholder="Enter client phone number" title="Student mobile number input box" autofocus required> 
                                 </div>
                                   <div class="form-group col-12">
                                   
                                         <div class="form-group">
                                      
                                                                                          <input type="text" value="<?php echo $_SESSION['username'] ;?>" class="bg-success" id="user" style="display: none;">

                                             <input type="submit" value="Update" class="bg-success" onclick="update()">
                                         </div>
                                   </div>
                               
                           </div>
                        

                   
                
                   
                                          
                                
                           
     
                         </div>
                           
                           
                           <label class="text-success" id="resulttext"></label>
         
                        
                        
                
                    
              
                        </div>
                
            
            
                  
            
            
        </body>
</html>