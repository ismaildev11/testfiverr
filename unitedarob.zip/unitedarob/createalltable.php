<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//CREATE TABLE `arobamirat`.`clients` (`id` INT NOT NULL AUTO_INCREMENT, `firstname` VARCHAR(50) NOT NULL , `lastname` VARCHAR(50) NOT NULL , `phonenumber` INT(20) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;