<table class="table table-striped table-hover ">    
    
    <tr>
        <td>ID</td>
        <td>First Name</td>
        <td>Last Name</td>
        <td>Phone Number</td>
       
        
    </tr>
     <?php require './stringCratePage.php';
                                       $string="select * from clients";

                                       require_once './db/dbConnectionConfigCheck.php';
                                       
                                        $newConnection2=OpenMyDbConnection();
                            if(is_int($newConnection2) && $newConnection2==0)
                            {
                                echo "step 1 problem check connection page";    return "step 1 problem check connection page";
                            }
                        else 
                        {
                       $sql=$string;//echo $sql."</br>";
                       
                           $result=mysqli_query($newConnection2, $sql)or die(mysqli_error($newConnection2));
                           // echo $result;
                           $test="";
                           // Numeric array
                         while ($row=mysqli_fetch_assoc($result))
                           {
                             echo "  <tr><td>";

                       echo   $row['id']. "</td><td>";    
                       echo   $row['firstname']. "</td><td>";    
                       echo   $row['lastname']. "</td><td>";    
                       echo   $row['phonenumber']. "</td>";    
                       echo   "<td class=\"btn btn-danger\" onclick=\"deletec(".$row['id'].")\">Delete </td>";    
            echo "</tr>";         
                                 
                           
                        }
                           


                           }
                       CloseMyDbConnection($newConnection2);                                    

  
                                      ?>
                                     
 
                                     
                                          
                                          </table>
        
        
       