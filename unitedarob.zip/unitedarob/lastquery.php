
     <?php 
     
 
     require './stringCratePage.php';
                                    $string="select event_time as time,
    user_host,
    thread_id,
    server_id,
    command_type,
    argument
from mysql.general_log
where user_host like 'root%'
order by event_time desc
limit 1;";

                                       require_once './db/dbConnectionConfigCheck.php';
                                       
                                        $newConnection2=OpenMyDbConnection();
                            if(is_int($newConnection2) && $newConnection2==0)
                            {
                                echo "step 1 problem check connection page";    return "step 1 problem check connection page";
                            }
                        else 
                        {
                    $sql=$string;
//echo $sql."</br>";
                       
                        $result=mysqli_query($newConnection2, $sql)or die(mysqli_error($newConnection2));
                           // echo $result;
                           require './db/dbmanager.php';
                
//echo $newConnection2->info;
    var_dump($result);

                           }
                          // echo $newConnection2->info;
                       CloseMyDbConnection($newConnection2);                                    

  
                                      ?>
                                     
 
                                     
                                          
                                      
        
        
       