<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
   
        <title>Success+ coaching Halishahar,Chittagong</title>
       
       <link rel="icon" href="./images/logo.ico" type="image/ico" sizes="16x16">.
       <!--fontawesome start-->
       <!script src="https://kit.fontawesome.com/eeaec62120.js"></script>
       <!--fontawesome end-->
       
       
 <!--Offline start-->
       
 <script src="myjsfolder/positioncount.js" type="text/javascript"></script>
  
 <script src="myjsfolder/myjsedit6.js" type="text/javascript"></script>
 <script src="myjsfolder/studentlistprnt.js" type="text/javascript"></script>
   
       <!--online files start-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap" rel="stylesheet">
   <!--online files end-->   
 <link href="./mycss/mycss.css" rel="stylesheet" type="text/css"/>
 <link href="./mycss/myresponsive.css" rel="stylesheet" type="text/css"/>

  
   
 
           
    <style>
        .adminheading
        {
          padding: 5px;
          padding-bottom: 0px;
          background-color: darkgrey;
                      border-bottom: 6px wheat outset;

        }
        
        .adminboxborder
        {
            border: 3px dotted whitesmoke;
            padding: 10px;
            background-color: #7efff5;
        }
        .adminboxborder1
        {
            border: 3px dotted whitesmoke;
            padding: 10px;
            background-color: #7efff5;
            border-bottom: 0px solid transparent;
        }
        .adminboxborder2
        {
            border: 3px dotted whitesmoke;
            padding: 10px;
            background-color: #7efff5;
              border-top: 0px solid transparent;
        }
     .row
{
    margin-left: 1%;
    margin-right: 1%;
}
body
{
    background-color: whitesmoke;
}
table {
  width:100%;
  
  margin: 0 auto;
  font-family:'Open Sans', 'Helvetica', 'Arial';
}


    </style>
   
    
    </head>
    <body> 
        
            
        
        
            
<div class="leftsidenav">
    <div class="">   
   
       <!-----  student mngmnt start-->
       <div class="row  mymenurow bg-info   "  data-toggle="collapse" data-target="#dashboard">
     
           <div class="col-1"></div> <div class="col-1"></div> <div class="col-11">  <a href="dashboard.php">    <p class="mytextBlack h4  float-left">&nbsp;My DashBoard</p > </a></div>
            </div><div class="col-1"></div>
        
      
       <div class="row  mymenurow bg-info    "  data-toggle="collapse" data-target="#studentmanagement">
     
           <div class="col-1"></div> <div class="col-11"> <p class="mytextBlack h4 ">Student Section</p ></div>
            </div>
       
        
        <div class="collapse" id="studentmanagement">
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiregistration.php">    <p class="mytextBlack h4  float-left">&nbsp;New Student</p > </a>
                    
                </div>
            </div>
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UiUpdateStudentInfo.php">    <p class="mytextBlack h4  float-left">&nbsp;Update Student</p > </a>
                    
                </div>
            </div>
             
            
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UIstudentsearchshow.php">    <p class="mytextBlack h4  float-left">&nbsp;Search Student</p > </a>
                </div>
            </div>
              
               
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UIcompleteProfile.php">    <p class="mytextBlack h4  float-left">&nbsp;Complete Profile</p > </a>
                </div>
            </div>
              
               
              
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uistudentlist.php">    <p class="mytextBlack h4  float-left ">&nbsp;Student List</p > </a>
                </div>
            </div>
               
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiAdmissionHistory.php">    <h6 class="mytextBlack h4  float-left ">Admission History</h6></a>
                </div>
            </div>
               
              
           
            
        </div>
        
       
       <!-----  student mngmnt end-->
        <!-----  result mngmnt start-->
       <div class="row  mymenurow bg-info   "  data-toggle="collapse" data-target="#resultmanagement">
     
            <div class="col-1"></div> <div class="col-11">  <p class="mytextBlack h4 ">Exam Management  </p > </div>
            </div>
       
        
        <div class="collapse" id="resultmanagement">
             
            <div class="row mymenusub bg-secondary   ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uicreateExam.php">    <p class="mytextBlack h4  float-left">&nbsp;New Exam</p > </a>
                </div>
            </div>
             
            
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiUpdateResult.php">    <p class="mytextBlack h4  float-left">&nbsp;Update Result</p > </a>
                </div>
            </div>
              
                 
                  
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiresultshow.php">    <p class="mytextBlack h4  float-left">&nbsp;Show Result</p > </a>
                </div>
            </div>
                 
                  
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UiIndividualResult.php">    <p class="mytextBlack h4  float-left">&nbsp;Individual Result</p > </a>
                </div>
            </div>
                 
                  <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiExamHistory.php">    <p class="mytextBlack h4  float-left ">&nbsp;Exam  History</p > </a>
                </div>
            </div>
               
              
               
              
        </div>
        
       
       <!-----  result mngmnt end-->
          <!-----  payMENT mngmnt start-->
       <div class="row  mymenurow bg-info    "  data-toggle="collapse" data-target="#paymentmanagement">
     
            <div class="col-1"></div> <div class="col-11">  <p class="mytextBlack h4 ">Payment Gateway  </p > </div>
            </div>
       
        
        <div class="collapse" id="paymentmanagement">
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uinewpayment.php">    <p class="mytextBlack h4  float-left">&nbsp;New Payment</p > </a>
                </div>
            </div>
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UiIndividualPayment.php">    <p class="mytextBlack h4  float-left">Individual Pay Rprt</p > </a>
                </div>
            </div>
             
            
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uidueReport.php">    <p class="mytextBlack h4  float-left">&nbsp;Due Report</p > </a>
                </div>
            </div>
              
               
                  <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uipaymentReport.php">    <p class="mytextBlack h4  float-left">&nbsp;Payment Report</p > </a>
                </div>
            </div>
                
                     
                
           
          
                 
             
            
        </div>
        
       
       <!-----  payment mngmnt end-->
          <!-----  SMS mngmnt start-->
       <div class="row  mymenurow bg-info    "  data-toggle="collapse" data-target="#smsmanagement">
     
            <div class="col-1"></div> <div class="col-11">  <p class="mytextBlack h4 ">SMS Controll  </p > </div>
            </div>
       
        
        <div class="collapse" id="smsmanagement">
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                                        <a href="UiResultSms.php">    <p class="mytextBlack h4  float-left"> Result SMS</p > </a>

                </div>
            </div>
             
            
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UIpersonalsms.php">    <p class="mytextBlack h4  float-left"> Personal SMS</p > </a>
                </div>
            </div>
              
               
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UIclasssms.php">    <p class="mytextBlack h4  float-left">Class/Batch SMS</p > </a>
                </div>
            </div>
              
               
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiSMSbalance.php">    <p class="mytextBlack h4  float-left">SMS Balance</p > </a>
                </div>
            </div>
              
               
              
           
            
        </div>
        
         <!-----  SMS new mngmnt start-->
       <div class="row  mymenurow bg-info    "  data-toggle="collapse" data-target="#smsmanagementnew">
     
            <div class="col-1"></div> <div class="col-11">  <p class="mytextBlack h4 ">SMS Controll new  </p > </div>
            </div>
       
        
        <div class="collapse" id="smsmanagementnew">
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UiResultSmsBand.php">    <p class="mytextBlack h4  float-left"> Result SMS</p > </a>

                </div>
            </div>
             
            
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UIpersonalsmsBand.php">    <p class="mytextBlack h4  float-left"> Personal SMS</p > </a>
                </div>
            </div>
              
               
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="UIclasssmsBand.php">    <p class="mytextBlack h4  float-left">Class/Batch SMS</p > </a>
                </div>
            </div>
              
               
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiSMSbalanceBand.php">    <p class="mytextBlack h4  float-left">SMS Balance</p > </a>
                </div>
            </div>
              
               
              
           
            
        </div>
          <!-----  SMS new mngmnt end-->
       <!-----  payment mngmnt end-->
          <!-----  expense mngmnt start-->
       <div class="row  mymenurow bg-info    "  data-toggle="collapse" data-target="#adminmanagement">
     
           <div class="col-1"></div> <div class="col-11">  <p class="mytextBlack h4 ">Admin Activity  </p > </div>
            </div>
       
        
        <div class="collapse" id="adminmanagement">
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiadminactivity.php">    <p class="mytextBlack h4  float-left">&nbsp;Activity List</p > </a>
                </div>
            </div>
             
            
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiadminactivity.php">    <p class="mytextBlack h4  float-left">&nbsp;User Control</p > </a>
                </div>
            </div>
              
               
              
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiadminactivity.php">    <p class="mytextBlack h4  float-left">&nbsp;History</p > </a>
                </div>
            </div>
            
        </div>
        
       
       <!-----  expense mngmnt end-->
          <!-----  expense mngmnt start-->
       <div class="row  mymenurow bg-info    "  data-toggle="collapse" data-target="#expensesmanagement">
     
           <div class="col-1"></div> <div class="col-11">  <p class="mytextBlack h4 ">Expenses Details  </p > </div>
            </div>
       
        
        <div class="collapse" id="expensesmanagement">
             
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uiexpenses.php">    <p class="mytextBlack h4  float-left">&nbsp;Add Cost</p > </a>
                </div>
            </div>
             
            
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uishowexpenses.php">    <p class="mytextBlack h4  float-left">&nbsp;Show cost</p > </a>
                </div>
            </div>
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uitodaystutioncollected.php">    <p class="mytextBlack h4  float-left">&nbsp;All Fees Collected</p > </a>
                </div>
            </div>
                
            <div class="row mymenusub bg-secondary    ">
                <div class="col-1"></div> <div class="col-11"> 
                    <a href="uipbalance.php">    <p class="mytextBlack h4  float-left">&nbsp;Balance Remaining</p > </a>
                </div>
            </div>
              
               
              
               
                
            
        </div>
        
       
       <!-----  expense mngmnt end-->
          
        
   
    
    
    
    
    
    
    
</div>  
  
 </div>
                
                
          
       