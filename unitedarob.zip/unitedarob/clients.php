    
  
<script>

function Load()
{
    
    var xmlhttp=new XMLHttpRequest();
  
            xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("mydashboard").innerHTML = this.responseText;
            }
        };
    
    xmlhttp.open("GET","clientsRequest.php",true);
    xmlhttp.send();
    afterFive();
}
function deletec(id)
{
    var  user=document.getElementById('user').value;  
    var xmlhttp=new XMLHttpRequest();
  
            xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                 if(parseInt(this.responseText)==1)
                {
                    window.location.reload();
                }
            }
        };
    
    xmlhttp.open("GET","deleterequest.php?id="+id+"&user="+user,true);
    xmlhttp.send();
   
}

</script>
<?php require './layout.php';?>
  

       
   
            <div class="main">
                                                             <input type="text" value="<?php echo $_SESSION['username'] ;?>" class="bg-success" id="user" style="display: none;">

                   <div class="h3 text-center  bg-info">All Clients</div>
                     
                <div id="mydashboard" style="border: .2vw groove  whitesmoke;">
                    
                     
                    
                </div>
                   
           
            
            
            

            </div>
            
       
    
       
    </body>
</html>
 