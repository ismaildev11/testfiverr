  
    
  
     <?php require './stringCratePage.php';
                                       $string="select * from clients";

                                       require_once './db/dbConnectionConfigCheck.php';
                                       
                                        $newConnection2=OpenMyDbConnection();
                            if(is_int($newConnection2) && $newConnection2==0)
                            {
                                echo "step 1 problem check connection page";    return "step 1 problem check connection page";
                            }
                        else 
                        {
                       $sql=$string;//echo $sql."</br>";
                       
                           $result=mysqli_query($newConnection2, $sql)or die(mysqli_error($newConnection2));
                           // echo $result;
                           $test="";
                           // Numeric array
                           $resultOut="<option >Select a Client to Edit</option>";
                         while ($row=mysqli_fetch_assoc($result))
                           {
                             echo "  <tr><td>";

                       $resultOut=$resultOut."<option value=".$row['id'].">".$row['firstname']." ".$row['lastname']."</option>";    
                             
                                 
                           
                        }
                           
$resultOut=$resultOut;

                           }
                       CloseMyDbConnection($newConnection2);                                    

  echo $resultOut;
                                      ?>
                                     
 
                                     
                                          
                                        
        
        
       