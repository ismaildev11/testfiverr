


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"></meta>
        <title>
	Login to admin panel
</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"/>
    <style type="text/css">
        .style1
        {
            width: 100%;
            background-color :White;
        }
        .style190
        {
            background-color :#EAEAEA;
        }
        .body
        {
        	margin-top :70px;
        }
        .style191
        {
            background-color : #EAEAEA;
            width: 188px;
        }
        p {
  text-align: center;
  font-size: 60px;
  margin-top: 0px;
}
    </style>
</head>
<body class ="body ">
    
    <div class="container-fluid">
        
        
   
     <form name="form1" method="post" action="confirmLogin.php" onsubmit="" id="form1">

    <div align="center">
        <div id="UpdatePanel1">
	
         <div style="width :520px;   border: solid black 1px; margin-top :20px; background-color :White ; ">
       <div align="center" style ="vertical-align:middle; background-color :#507CD1;">
       <span style=" padding-top:50px; font-family:Arial; font-weight:bold; font-size:20px; color:White;">
           Login</span></div> 
        <table class="style1">
            
            <tr>
                <td class="style191" rowspan="5">
                    <img id="Image1" src="images/logo.png" style="height:150px;width:136px;border-width:0px;" />
                </td>
                
                
            </tr>
            <tr>
                <td align="left" class="style190">
                    &nbsp;</td>
                <td align="left" class="style190">
                    <span id="laMeg" style="color:Red;"></span>
                </td>
            </tr>
            <tr>
                <td class="style190">
                    User ID</td>
                <td class="style190">
                    <input name="username" type="text" id="txtusername" autocomplete="off" style="width:200px;" />
                    <span id="RequiredFieldValidator1" style="color:Red;visibility:hidden;">*</span>
                </td>
            </tr>
            <tr>
                <td class="style190">
                    Password</td>
                <td class="style190">
                    <input name="userpassword" type="password" id="txtpassword" style="width:200px;" />
                     <span id="RequiredFieldValidator2" style="color:Red;visibility:hidden;">*</span>
                </td>
                
            </tr>
            <tr>
                <td class="style190">
                    &nbsp;</td>
                <td class="style190">
                    <input type="submit" name="btnLogin" value="Login"  id="btnLogin" style="width:70px;" />
                    &nbsp;<input type="submit" onclick="alert()"name="btnCancel" value="Cancel" id="btnCancel" style="width:70px;" />
                </td>
            </tr>
            
            
        </table>
         <div align="center" style ="height :30px; background-color :#507CD1;">
           </div> 
        </div>
    
</div>
    </div>
    
   
</form>
    
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
