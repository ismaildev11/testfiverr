-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2022 at 02:23 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arobamirat`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phonenumber` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `firstname`, `lastname`, `phonenumber`) VALUES
(5, 'Ismail3', 'Hossain3', 1970430797),
(6, 'Ismail', 'Hossain', 1970430797),
(7, 'Ismailr', 'Hossain', 1970430797),
(8, 'IsmailT', 'Hossain', 1970430797),
(10, '', '', 0),
(11, 'Ismail', 'Hossain', 1970430797),
(12, '', '', 0),
(13, '', '', 0),
(14, '', '', 0),
(15, 'Ismail', 'Hossain', 1970430797),
(16, '', '', 0),
(17, '', '', 0),
(18, 'Ismail', 'Hossain', 1970430797),
(19, '', '', 0),
(20, '', '', 0),
(21, '', '', 0),
(22, '', '', 0),
(23, '', '', 0),
(24, 'Ismail', 'Hossain', 1970430797),
(25, 'Ismail', 'Hossain', 1970430797),
(26, '', '', 0),
(27, 'Ismail5', 'Hossain5', 1970430797),
(28, '', '', 0),
(29, 'Ismail', 'Hossain', 1970430797),
(30, '', '', 0),
(31, 'Ismail', 'Hossain', 1970430797),
(32, 'Ismail', 'Hossain', 1970430797),
(33, 'Ismail', 'Hossain', 1970430797),
(34, 'Ismail', 'Hossain', 1970430797),
(35, 'Ismail', 'Hossain', 1970430797),
(36, 'Ismail', 'Hossain', 1970430797),
(37, 'Ismail', 'Hossain', 1970430797),
(38, 'test', 'tse', 1970430797),
(39, 'test', 'Hossain', 1970430797),
(40, 'test3', 'Hossain', 1970430797),
(41, 'Ismail', 'Hossain', 1970430797),
(42, 'Ismail7', 'Hossain', 1970430797),
(43, 'Ismail99', 'Hossain', 1970430797),
(44, 'Ismail12', 'Hossain', 1970430797),
(45, 'Ismail12', 'Hossain', 1970430797),
(46, 'Ismail12', 'Hossain', 1970430797),
(47, 'Ismail12', 'Hossain', 1970430797),
(48, 'Ismail', 'Hossain', 1970430797),
(49, 'Ismail', 'Hossain', 1970430797),
(50, 'Ismail', 'Hossain', 1970430797),
(51, 'Ismail', 'Hossain', 1970430797),
(52, 'Ismail', 'Hossain', 1970430797),
(53, 'Ismail', 'Hossain', 1970430797),
(54, 'Ismail', 'Hossain', 1970430797),
(55, 'Ismail', 'Hossain', 1970430797),
(56, 'Ismail', 'Hossain', 1970430797),
(57, 'Ismail', 'Hossain', 1970430797),
(58, 'Ismail', 'Hossain', 1970430797),
(59, 'Ismail', 'Hossain', 1970430797),
(60, 'Ismail', 'Hossain', 1970430797),
(61, 'Ismail', 'Hossain', 1970430797),
(62, 'Ismail', 'Hossain', 1970430797),
(63, 'Ismail', 'Hossain', 1970430797),
(64, 'Ismail', 'Hossain', 1970430797),
(65, 'Ismail', 'Hossain', 1970430797),
(66, 'Ismail', 'Hossain', 1970430797),
(67, 'Ismail', 'Hossain', 1970430797),
(68, 'Ismail', 'Hossain', 1970430797),
(69, 'Ismail', 'Hossain', 1970430797),
(70, 'Ismail', 'Hossain', 1970430797),
(71, 'Ismail', 'Hossain', 1970430797),
(72, 'Ismail', 'Hossain', 1970430797),
(73, 'Ismail', 'Hossain', 1970430797),
(74, 'Ismail', 'Hossain', 1970430797),
(75, '', '', 0),
(76, 'Ismail', 'Hossain', 1970430797),
(77, 'Ismail', 'Hossain', 1970430797),
(78, 'Ismail', 'Hossain', 1970430797),
(79, 'Ismail', 'Hossain', 1970430797),
(80, 'Ismail', 'Hossain', 1970430797),
(81, '', '', 0),
(82, 'Ismail', 'Hossain', 1970430797),
(83, '', '', 0),
(84, '', '', 0),
(85, '', '', 0),
(86, '', '', 0),
(87, '', '', 0),
(88, 'Ismail', 'Hossain', 1970430797),
(89, 'Ismail', 'Hossain', 1970430797),
(90, 'Ismail', 'Hossain', 1970430797),
(91, 'Ismail', 'Hossain', 1970430797),
(92, 'Ismail', 'Hossain', 1970430797),
(93, 'Ismail', 'Hossain', 1970430797),
(94, 'Ismail', 'Hossain', 1970430797),
(95, 'Ismail', 'Hossain', 1970430797),
(96, 'Ismail', 'Hossain', 1970430797),
(97, 'Ismail4', 'Hossain', 1970430797),
(98, 'Ismail', 'Hossain', 1970430797),
(99, 'Ismail', 'Hossain', 1970430797),
(100, 'Ismail', 'Hossain', 1970430797),
(101, 'Ismail', 'Hossain', 1970430797),
(102, 'Ismail', 'Hossain', 1970430797),
(103, 'Ismail', 'Hossain', 1970430797),
(104, 'Ismail', 'Hossain', 1970430797),
(105, 'Ismail', 'Hossain', 1970430797),
(106, 'Ismail', 'Hossain', 1970430797),
(107, 'Ismail', 'Hossain', 1970430797),
(108, 'Ismail', 'Hossain', 1970430797),
(109, 'Ismail', 'Hossain', 1970430797);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `historyid` int(11) NOT NULL,
  `actionname` varchar(40) NOT NULL,
  `effectedid` int(11) NOT NULL,
  `changedby` int(11) NOT NULL,
  `timedateofaction` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`historyid`, `actionname`, `effectedid`, `changedby`, `timedateofaction`) VALUES
(1, 'new', 70, 0, '2022-09-06 21:16:19'),
(2, 'new', 71, 0, '2022-09-06 21:17:37'),
(3, 'new', 72, 0, '2022-09-06 21:18:38'),
(4, 'new', 73, 0, '2022-09-06 21:25:51'),
(5, 'new', 74, 0, '2022-09-06 21:27:14'),
(6, 'new', 75, 0, '2022-09-06 21:27:20'),
(7, 'new', 76, 0, '2022-09-06 21:27:28'),
(8, 'new', 77, 0, '2022-09-06 21:27:55'),
(9, 'new', 78, 0, '2022-09-06 21:29:23'),
(10, 'new', 79, 0, '2022-09-06 21:30:24'),
(11, 'new', 80, 0, '2022-09-06 21:31:06'),
(12, 'new', 81, 0, '2022-09-06 21:32:19'),
(13, 'new', 82, 0, '2022-09-06 22:01:28'),
(14, 'new', 83, 0, '2022-09-06 22:01:35'),
(15, 'new', 84, 0, '2022-09-06 22:01:36'),
(16, 'new', 85, 0, '2022-09-06 22:01:37'),
(17, 'new', 86, 0, '2022-09-06 22:01:38'),
(18, 'new', 87, 0, '2022-09-06 22:01:38'),
(19, 'new', 88, 0, '2022-09-06 22:16:01'),
(20, 'new', 89, 0, '2022-09-06 22:17:09'),
(21, 'new', 90, 0, '2022-09-06 22:18:38'),
(22, 'new', 91, 0, '2022-09-06 22:19:15'),
(23, 'new', 92, 0, '2022-09-06 22:20:08'),
(24, 'new', 93, 0, '2022-09-06 22:20:53'),
(25, 'new', 94, 0, '2022-09-06 22:23:34'),
(26, 'new', 95, 0, '2022-09-06 22:53:41'),
(27, 'new', 96, 0, '2022-09-06 22:53:55'),
(28, 'new', 97, 0, '2022-09-06 23:14:28'),
(29, 'new', 98, 0, '2022-09-06 23:19:29'),
(30, 'new', 99, 0, '2022-09-06 23:21:33'),
(31, 'new', 100, 0, '2022-09-06 23:22:38'),
(32, 'new', 101, 0, '2022-09-06 23:28:18'),
(33, 'new', 102, 0, '2022-09-06 23:34:06'),
(34, 'new', 103, 0, '2022-09-06 23:35:22'),
(35, 'new', 104, 0, '2022-09-06 23:41:36'),
(36, 'new', 105, 0, '2022-09-06 23:42:27'),
(37, 'new', 106, 0, '2022-09-06 23:43:14'),
(38, 'new', 107, 0, '2022-09-06 23:44:16'),
(39, 'new', 108, 0, '2022-09-06 23:45:02'),
(40, 'new', 108, 0, '2022-09-06 23:48:17'),
(41, 'new', 108, 0, '2022-09-06 23:50:42'),
(42, 'new', 108, 0, '2022-09-06 23:52:36'),
(43, 'new', 108, 0, '2022-09-06 23:54:24'),
(44, 'edit', 108, 0, '2022-09-06 23:56:55'),
(45, 'delete', 108, 0, '2022-09-07 00:20:04'),
(46, 'delete', 108, 0, '2022-09-07 00:20:23'),
(47, 'delete', 108, 0, '2022-09-07 00:20:43'),
(48, 'delete', 108, 0, '2022-09-07 00:20:46'),
(49, 'delete', 108, 0, '2022-09-07 00:20:48'),
(50, 'new', 109, 0, '2022-09-07 00:21:21'),
(51, 'edit', 109, 0, '2022-09-07 00:21:41');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `username` varchar(50) NOT NULL,
  `userpass` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`username`, `userpass`) VALUES
('admin', 'testpass');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`historyid`),
  ADD KEY `effectedid` (`effectedid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `historyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `history_ibfk_1` FOREIGN KEY (`effectedid`) REFERENCES `clients` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
