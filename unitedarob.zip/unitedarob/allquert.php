<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *//*
CREATE TABLE history ( 
        historyid INT NOT NULL AUTO_INCREMENT, 
        actionname VARCHAR(40) NOT NULL, 
        effectedid INT NOT NULL , 
        changedby INT NOT NULL, 
        timedateofaction TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (historyid) , FOREIGN KEY (effectedid) REFERENCES clients(id));