<?php
@ob_start();
session_start();
 //echo "test ok";


//var_dump($_POST['username']);
$userName=$_POST['username'];
 $userPass=$_POST['userpassword'];
require_once './db/dbConnectionConfigCheck.php';
$anewconnection= OpenMyDbConnection();
require_once './stringCratePage.php';

$sql=CreateString4UserShowCheck($userName,$userPass);
//$sql="select * from allstudent";
//echo $sql;

$result = mysqli_query($anewconnection,$sql);
//print_r($result->fetch_row());
//die();
//var_dump($result);
//echo mysqli_num_rows($result);die();

if(mysqli_num_rows($result)==1)
{ 
   // print_r($result->fetch_row());die();

    //print_r($_SESSION);
    mysqli_close($anewconnection);
   
    //session_start();
    $_SESSION['login']=true;
    
     while ($row=mysqli_fetch_assoc($result))
                           {                            
                                    
                     //$_SESSION['uid']=$row['id'];  
    $_SESSION['username']=$row['username'];            
                           }
                           
                           
session_regenerate_id();///for session hijacking
   

    header("Location: clients.php");
    //echo "bal";die();
    //print_r($_SESSION);
}
 else
     {   mysqli_close($anewconnection);   $_SESSION['login']=false;
header("Location: login.php");
    }
    ?>