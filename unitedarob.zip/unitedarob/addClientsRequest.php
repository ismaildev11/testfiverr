
     <?php 
     
     $user=  filter_input(INPUT_GET, "user");
     $firstname=  filter_input(INPUT_GET, "firstname");
$lastname=  filter_input(INPUT_GET, "lastname");
$phonenumber=  filter_input(INPUT_GET, "phonenumber");
     require './stringCratePage.php';
                                       $string="insert into clients (firstname,lastname,phonenumber) values ('$firstname','$lastname','$phonenumber')";

                                       require_once './db/dbConnectionConfigCheck.php';
                                       
                                        $newConnection2=OpenMyDbConnection();
                            if(is_int($newConnection2) && $newConnection2==0)
                            {
                                echo "step 1 problem check connection page";    return "step 1 problem check connection page";
                            }
                        else 
                        {
                       $sql=$string;
//echo $sql."</br>";
                       
                          // $result=mysqli_query($newConnection2, $sql)or die(mysqli_error($newConnection2));
                           // echo $result;
                           require './db/dbmanager.php';
                       
                if (insertnewEntry($string)==1)
                {
                 //  $_SESSION['addclient']="New Client Added";
                    $lastidsql="SELECT id from clients order by id desc limit 1";
                    $lastidrow=mysqli_query($newConnection2,$lastidsql);
                     while ($row=mysqli_fetch_assoc($lastidrow))
                           {     $lastid=$row['id'];                         
                        }
                    //echo $lastid;
                      $historySql="insert into history (actionname,effectedid,changedby) VALUES ('new',".$lastid.","."'$user'".")";
                     
                      if( insertnewEntry($historySql)==1){ echo 1;}
             // var_dump( $historySql);
                         
               //    header("Location: ./clients.php");

                }
                else
                {
                    echo 0;
                }


                           }
                       CloseMyDbConnection($newConnection2);                                    

  
                                      ?>
                                     
 
                                     
                                          
                                      
        
        
       