<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="./clients.php">All Clients</a></li>
      <li><a href="./addClient.php">Add Clients</a></li>
      <li><a href="./editClient.php">Edit Clients</a></li>
    </ul>
  </div>
</nav>