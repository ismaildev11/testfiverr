<?php
echo 

"<section class=\"my-2\">
                
           <div class=\"row bg-info\"\">
            
               <div class=\"col-12 col-sm-9 h1 text-light\" >
               <a target=\"_blank\" href=\"new.php\" class=\"text-light\"> New Management System   </a>
               </span> 
              
               </div>
               
               <div class=\"col-12 col-sm-3\" >     <a href=\"logout.php\" class=\"float-right \"><h3 style=\"color: white;\">Log Out</h3></a>
               </div>

           </div>
       


                 </section>";

        ?>
          
