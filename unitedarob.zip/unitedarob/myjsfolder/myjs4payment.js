
   function  payprint(divId,contenthEADHING)
{
    ///time srart
    var atime=new Date();
    var yy=atime.getFullYear();
    var m=atime.getMonth()+1;
    var d=atime.getDate();
    var H=atime.getHours();
    var min=atime.getMinutes();
    var se=atime.getSeconds();
    var ttim= "Printing Date: "+d+"/"+m+"/"+yy+"::"+H+":"+min+":"+se;
   ///time end
   //var heading1="heelo";
   var heading="<table><tr> <td  rowspan=\"6\" colspan=\"2\" width=\"38%\"  align=\"center\"><span style=\"font-family:Script MT ;color:red;font-size:60px;\">Success+</span><BR><span style=\"font-size:24px;font-family: \"Times New Roman\", Times, serif;\">B-Block,Halishahar,Chattagram <br>01726-576693</span></td></tr></table>";           

   var divContents = document.getElementById(divId).innerHTML; 
   //var divId2Content = document.getElementById(divId2).innerHTML; 
            var a = window.open('', '', 'height=900, width=1500'); 
            a.document.write('<html>'); 
            a.document.write('<body ><b align=\"right\">'+ttim+'</b><br>'); 
            //a.document.write(divId2Content); 
           // var stringcoming='Summery Print';
            //alert(contenthEADHING);
           // if(contenthEADHING.localeCompare(stringcoming))
           // {
                
           // }
           // else
           // {
           //     a.document.write(heading);     
           // }
        
             //a.document.write('<center><h3 >'+contenthEADHING+'</h3></center>'); 

            a.document.write(divContents); 
            a.document.write('</body></html>'); 
      //  a.focus();
  
    //a.print();
  //a.close();  
  a.document.close(); 
         a.print(); 
       //  a.close();  
  //  return true;    
        
        
        
}


  