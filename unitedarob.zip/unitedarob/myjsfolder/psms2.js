/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




     var mobilearray= new Array();  
     var deliveryrrrport="";
     var showflag=0; //0mens show hoi nai ekono
     
                              
                                function smsformat(smsfNumber)
    {
        if(smsfNumber===1)
        {
          var smsformat1="Dear Students: Your class will start from tommorrow,Success+,01726576693";
            document.getElementById('message').value=smsformat1; 
        }
       else if(smsfNumber===2)
        {
          var smsformat2="Dear Students: Tommorrow Coaching will remain closed on account of Bad Weather. Regards,Success+,01726576693";
      document.getElementById('message').value=smsformat2;
        }
        
       else if(smsfNumber===3)
        {
         var smsformat3="Your child ((Student Name))  got ((Obtained Marks)) out of ((Exam Total Marks)) marks in ((Exam Subject Name)),Exam Date:((Exam  Date )),Merit Position:((Merit Position)),GPA-Letter:((Obtained GPA-Letter)),GPA-Point:((Obtained GPA-Point)),Success+,01726576693";
      document.getElementById('message').value=smsformat3; 
        }
       else if(smsfNumber===4)
        {
        /* var smsformat3="Dear Student, the last date of paying fees is 15 May. You are requested to pay the fees before 15 May,Success+,01726576693";*/
        var smsformat3="You have successfully completed your child admission in Success+ Coaching. Thank you so much for being with us. Director, Success+ Coaching. Contact : 01726-576693 ";
      document.getElementById('message').value=smsformat3; 
        }  
        else if(smsfNumber===5)
        {
        /* var smsformat3="Dear Student, the last date of paying fees is 15 May. You are requested to pay the fees before 15 May,Success+,01726576693";*/
        var smsformat3="Dear Guardian. Assalamu Alaikum. Your child was absent today. Please sent him/her from tomorrow. Thanks for being with us. Director, Success+ Coaching. Contact : 01726-576693";
      document.getElementById('message').value=smsformat3; 
        }
        
         
       
     
      
      
    }
                                function incr(widthincreasby)
    {
       var prevalue=parseInt(document.getElementById('myProgress').value);
       //alert(prevalue);
                document.getElementById('myProgress').value=prevalue+widthincreasby; 
    }
   
          function show()
          {
                var MESSAGEbOX=document.getElementById('message').value;  
        var MOBILE=document.getElementById('to').value;
           
        
        if(MOBILE=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('to').style.border="2px solid red";  
          document.getElementById('message').style.border="2px solid red";  
        }
        else
        {
              if(parseInt(showflag)==0)
              {
                    {  
      
        var single="";
     //alert(MOBILE.charAt(5));
      document.getElementById("tableshow").style.display = "block";
      document.getElementById("tableshow").style.visibility = "visible";
     var i=0;
     var count=0;
         var table = document.getElementById("tableshow"); 
          
    
                  count++;
        for(i=0;i<MOBILE.length;i++)
        {//alert(MOBILE.charAt(i));
            if(MOBILE.charAt(i).toString()==",")
            {
            // var table = document.getElementById("tableshow"); 
        mobilearray.push(single);
    var row = table.insertRow();
  
                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;
                  single="";
                  count++;
              }
              else  if( parseInt(MOBILE.length-1)==i)
            {
            single=single+MOBILE.charAt(i);
            var row = table.insertRow();
          mobilearray.push(single);

                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;
                  single="";
                  count++;
            }
          
            else
            {
              single=single+MOBILE.charAt(i);     
            }
        }
           document.getElementById("tableshow").width="100%";
           showflag=1
    }
              }
              else
              {
                  
              }
          } }
     
  function testsend()
    {
        
              var MESSAGEbOX=document.getElementById('message').value;  
        var MOBILE=document.getElementById('to').value;
           
        
        if(MOBILE=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('to').style.border="2px solid red";  
          document.getElementById('message').style.border="2px solid red";  
        }
        else
        { document.getElementById('message').disabled=true;  
        document.getElementById('to').disabled=true; 
        anima( );
      // show();
       disableButton();
     var allm=document.getElementById('to').value;
        document.getElementById('tableshow').style.display="none";
 cale(allm);
 // SoB  ghulo eksathe send hoitace.......................
    }

    }
  




 function methodLetterCount( someLetter)
    {
        document.getElementById('idWordCount').innerHTML= someLetter.length;
    }
 function anima( )
    {
       document.getElementById('try').classList.add('container');
       
       document.getElementById('boxid').classList.add('box');
       document.getElementById('borderoneid').classList.add('border');
       document.getElementById('borderoneid').classList.add('one');
       document.getElementById('bordertwo').classList.add('border');
       document.getElementById('bordertwo').classList.add('two');
       document.getElementById('borderthree').classList.add('border');
       document.getElementById('borderthree').classList.add('three');
       document.getElementById('borderfour').classList.add('border');
       document.getElementById('borderfour').classList.add('four');
       document.getElementById('lineone').classList.add('line');
       document.getElementById('lineone').classList.add('one');
       document.getElementById('linetwo').classList.add('line');
       document.getElementById('linetwo').classList.add('two');
       document.getElementById('linethree').classList.add('line');
       document.getElementById('linethree').classList.add('three');
       //document.getElementById('try').style.visibility="visible";
    }
 function animaStop( )
    {   // document.getElementById('some').innerHTML="";  
        document.getElementById('message').value="";  

document.getElementById('to').value="";
       document.getElementById('try').classList.remove('trydancing');
        document.getElementById('try').style.visibility="hidden";
    // location.reload();
    }
 function cale(single)
   { var message=document.getElementById('message').value; 
      
              //  document.getElementById("tableshow").innerHTML="";
           
            var request = new XMLHttpRequest();
           
            request.open('POST', 'requestSendApiBand.php', /* async = */ true);

            var formData = new FormData();
            formData.append('to',single);
            formData.append('message', message);

            request.send(formData);
            request.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {   //alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged);
deliveryrrrport=deliveryrrrport+" \n "+this.responseText;
     document.getElementById('deliveryrrrport').innerHTML=deliveryrrrport;  
           animaStop( );
           smsBlanceafterSending();
                 
            }
        };
    
              }
 function ResetAll()
    {   document.getElementById('message').disabled=false;  
        document.getElementById('to').disabled=false; 
        mobilearray= new Array();
      //  alert(mobilearray[0]);
       document.getElementById('message').value="";  
        document.getElementById('to').value="";
      
              // document.getElementById('hiddentag').innerHTML="";
               document.getElementById('tableshow').innerHTML="";
                // document.getElementById('hiddentag').style.visibility="hidden";
          document.getElementById('sendsmsid').disabled = false;

          window.location.reload();
    }




	function disableButton(){
		document.getElementById('sendsmsid').disabled = true;
		//alert("Button has been disabled.");
	}
	function smsBlanceafterSending(){
		 var xmlhttp = new XMLHttpRequest();
             xmlhttp.open("GET", "smsBalanceaftersending.php?", true);
//       
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("balanceAfterSending").innerHTML = this.responseText;
            }
        };
	}
  function singleSend()
          { var showflag=0;
                   var MESSAGEbOX=document.getElementById('message').value;  
        var MOBILE=document.getElementById('to').value;
           
        
        if(MOBILE=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('to').style.border="2px solid red";  
          document.getElementById('message').style.border="2px solid red";  
        }
        else
        { 
              if(parseInt(showflag)==0)
              {
                    
       
       
        var single="";
     //alert(MOBILE.charAt(5));
      document.getElementById("tableshow").style.display = "block";
      document.getElementById("tableshow").style.visibility = "visible";
     var i=0;
     var count=0;
         var table = document.getElementById("tableshow"); 
          
    
                  count++;
        for(i=0;i<MOBILE.length;i++)
        {//alert(MOBILE.charAt(i));
            if(MOBILE.charAt(i).toString()==",")
            {
            // var table = document.getElementById("tableshow"); 
               //  alert(single.length);
            if(single.length==0)
            {
                            //alert();  
            }
            else
            {
                    mobilearray.push(single);
                          //  alert(single);
  //  alert( setTimeout( cale(single), 2000));
      setTimeout( cale(single), 2000);
    /*var row = table.insertRow();
  
                var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;*/
                  single="";
                  count++;
            }
              }
              else  if( parseInt(MOBILE.length-1)==i)
            {
            single=single+MOBILE.charAt(i);
         /*   var row = table.insertRow();
          mobilearray.push(single);

                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;
                                  */
                                   setTimeout( cale(single), 2000);
                  single="";
                  count++;
            }
          
            else
            {
              single=single+MOBILE.charAt(i);     
            }
        }
           document.getElementById("tableshow").width="100%";
           showflag=1
    
              }
              else
              {
                  
              }
          }
          }