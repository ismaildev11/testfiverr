
   function methodFindingPaymentReport()
    { 
          var idMonth =document.getElementById('idMonthSelectionBox').value;
             
   var class1=document.getElementById('idclass').value;
       // alert(class1);
       if(parseInt(class1)===0 && parseInt(idMonth)===0)
    {        document.getElementById('idclass').style.border="4px solid red";
         document.getElementById('idMonthSelectionBox').style.border="4px solid red";  
    } 
      else   if(parseInt(class1)===0 && parseInt(idMonth)!==0)
    {        document.getElementById('idclass').style.border="4px solid red";  
        document.getElementById('idMonthSelectionBox').style.border="4px solid #1E90FF";  
    } 
    else if(parseInt(idMonth)===0 && parseInt(class1)!==0)
    {
         document.getElementById('idclass').style.border="4px solid #1E90FF";  
      document.getElementById('idMonthSelectionBox').style.border="4px solid red";  
    }
    else
    {    document.getElementById('idclass').style.border="4px solid #1E90FF";  
      document.getElementById('idMonthSelectionBox').style.border="4px solid #1E90FF";
        var xmlhttp;
           if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange = function() {
                if (this.readyState === 4 && this.status === 200) {
                   // document.getElementById("txtHint").innerHTML = this.responseText;
                    document.getElementById("txtHint").innerHTML = this.responseText;
                                        document.getElementById("txtHint2").style.display = "none";  
                    document.getElementById("txtHint").style.display = "inline";  

                        }
            };
        //xmlhttp.open("GET","http://ismailbd.rf.gd",true);
           xmlhttp.open("GET","requestpaymentReport.php?class="+class1+"&& month="+idMonth,true);
            xmlhttp.send();
            
    }
    
    var time= new Date();
    var second=time.getSeconds();
    var minute=time.getMinutes();
    var hour=time.getHours();
    var outtime=hour+":"+minute+":"+second;
    document.getElementById('idtime').innerHTML=outtime;
    }
   
   function deletePay(pid,cid)
   {
       //alert(pid+cid);
      if( confirm("Are You Sure To Delete! <Cancel> If not click on cancel...<OK> Click OK to confirm delete."))
      {
          var xmlhttp;
           if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange = function() {
                if (this.readyState === 4 && this.status === 200) {
                   // document.getElementById("txtHint").innerHTML = this.responseText;
                   // 
                  // alert(this.responseText);
                  if(parseInt(this.responseText)==1)
                  {
                    document.getElementById("txtHint2").style.display = "inline";  
                    document.getElementById("txtHint").style.display = "none";  
                    document.getElementById("txtHint2").innerHTML = "...Deleted Successfully..";  
                    document.getElementById("txtHint2").style.backgroundColor="green";
                    document.getElementById("txtHint2").style.color="white";
                //   document.getElementById('idMonthSelectionBox').value = '';
                   document.getElementById('idclass').value = '';
                   document.getElementById('idclass').style.border="4px solid red";
         document.getElementById('idMonthSelectionBox').style.border="4px solid red";  
                  }else{}
                        }
            };
        //xmlhttp.open("GET","http://ismailbd.rf.gd",true);
           xmlhttp.open("GET","requestpaymentReportDelete.php?pid="+pid+"&& cid="+cid,true);
            xmlhttp.send();
      }
   }