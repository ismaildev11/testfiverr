/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


      
                    function MethodTogetinfoForUpdate(id)
                    {
          document.getElementById('allp').style.display="inline";
                    if(id===0)
                    {
                        id= document.getElementById('idInputbox').value;
                           // alert("hello");
                    }
                    else
                    {
                        id=2006502;
                    }
                    
                 
                   if (id.length!==0) 
                    {     
                                   var  xmlhttp2=new XMLHttpRequest();    
                                    xmlhttp2.onreadystatechange = function()
                                    {
                                        if(this.readyState===4 && this.status===200)
                                        {
                                          
                                         //   
                                             var output = new Array();  
                    output =JSON.parse(this.responseText);
              // alert(output.classn);
               //
                                                          // alert(output.admissiondate);
                                                          if(output!==null)
                                                          { document.getElementById('idInputbox').style.border="4px solid green";
                                                                   var atime= new Date(output.admissiondate);
                                        var yy=atime.getFullYear();
                                        var m=atime.getMonth()+1;
                                        var d=atime.getDate();
                                        document.getElementById('dInputAdmissionDate').innerHTML=d+"/"+m+"/"+yy;
                                        
                                          var atime= new Date(output.activedate);
                                        var yy=atime.getFullYear();
                                        var m=atime.getMonth()+1;
                                        var d=atime.getDate();
                                        document.getElementById('dInputActiveDate').innerHTML=d+"/"+m+"/"+yy;
                                        
                                        document.getElementById('dInputDActiveDate').innerHTML=output.deactivedate;
                                        document.getElementById('idcoachingId').innerHTML=output.coachingid;
                                        document.getElementById('dInputCIDr').value=output.coachingid;
                                      
                                        
                                          document.getElementById('dInputmonthlypayment').value=output.monthlypay;
                                          document.getElementById('BdInputmonthlypayment').innerHTML=output.monthlypay;
                                        document.getElementById('dInputadmissionpayment').value=output.admissionpayment;
                                        document.getElementById('BdInputadmissionpayment').innerHTML=output.admissionpayment;
                                         
          
                                            document.getElementById('dInputSname').value=output.sname;
                                            document.getElementById('BdInputSname').innerHTML=output.sname;
                                        //document.getElementById('dInputSGurdianname').value=output.gname;
                                         document.getElementById('BdInputSGurdianname').innerHTML=output.gname;
                                         
                                         document.getElementById('dInputSmobilenumber').value=output.mobile1; 
                                         document.getElementById('BdInputSmobilenumber').innerHTML=output.mobile1; 
                                       //document.getElementById('dInputaddress').value=output.address; 
                                         document.getElementById('BdInputaddress').innerHTML=output.address; 
                                         
                                             document.getElementById('dinputschool').value=output.school;
                                             document.getElementById('Bdinputschool').innerHTML=output.schoolname;
                                             
                                             document.getElementById('dInputclass').innerHTML=output.classn;
                                      
                                        document.getElementById('Bidbatch').innerHTML=output.sectionname;
                                   }
                                   else
                                   { document.getElementById('idInputbox').style.border="2px solid red";}
                               }
                                    };//state change function end here
                                    xmlhttp2.open("GET","requestGetAstudentToUpdate.php?id="+id,true);
                                    xmlhttp2.send();
                                    
                       }
                         else
                    {
                    document.getElementById('idInputbox').style.border="2px solid red";
                    }
                    
                   }
                       
                        function methodUpdatestudent() 
{
  var  coachingid=document.getElementById('idInputbox').value;   
  var  Newcoachingid=document.getElementById('dInputCIDr').value;   
  var  dInputSname=document.getElementById('dInputSname').value;   
  var  BInputAdmissionDate=document.getElementById('BInputAdmissionDate').value; // alert(BInputAdmissionDate);
 var   dInputSmobilenumber=document.getElementById('dInputSmobilenumber').value;  //  alert(dInputSmobilenumber);
  var  BInputclass=document.getElementById('BInputclass').value;   // alert(dInputaddress);
  var  Bidbatch=document.getElementById('BidbatchBOX').value;   // alert(dInputaddress);
 var   dinputschool=document.getElementById('dinputschool').value;    //alert(dinputschool);
//alert(dInputsection);
 var   dInputmonthlypayment= document.getElementById('dInputmonthlypayment').value;
 var dInputadmissionpayment=  document.getElementById('dInputadmissionpayment').value;
if(BInputAdmissionDate.toString()==="") {
    
    BInputAdmissionDate=document.getElementById('dInputAdmissionDate').innerHTML;
    alert(BInputAdmissionDate);
}
if(BInputclass==="Select Class"){ document.getElementById('BInputclass').style.border="4px solid red";}

else if(Bidbatch==="All") {document.getElementById('BidbatchBOX').style.border="4px solid red";}
else if(dinputschool==="0") {document.getElementById('dinputschool').style.border="4px solid red";}
else{  var xmlhttp = new XMLHttpRequest();
    //  xmlhttp.open("GET", "gethint.php?q="+str, true);
        xmlhttp.open("GET", "requestUpdateStudent.php?coachingid="+coachingid+"&&dInputSname="+dInputSname+"&Bidbatch="+Bidbatch+"&&dInputSmobilenumber="+dInputSmobilenumber+
"&BInputclass="+BInputclass+"&&dinputschool="+dinputschool+"&&dInputmonthlypayment="+dInputmonthlypayment+'&dInputadmissionpayment='+dInputadmissionpayment+"&BInputAdmissionDate="+BInputAdmissionDate+"&Newcoachingid="+Newcoachingid, true);
//      xmlhttp.open("GET", "RequestCreateExamAndInsertmarks.php?class="+classSelected+"&batch="+batchSelected+"&group="+groupSelected+"&date="+examdate+"&Inputexamsubject="+subject+"&marks="+exammarks, true);

        
           
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState === 4 && this.status === 200) 
            {
                //document.getElementById("txtHint").innerHTML = this.responseText;
                alert(this.responseText);
               // window.location.reload();
                window.location.href = "./UiUpdateStudentInfo.php";
            }
        };
    }
    
}function showHint(str) {
    if (str.length === 0) {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState === 4 && this.status === 200)
            { 
                if(parseInt(this.responseText)===1)
                {     document.getElementById("idcoachingId").style.border  ="4px solid green" ;
                      document.getElementById("txtHint").innerHTML ="" ;
                }
                else if(parseInt(this.responseText)===-1)
                {
                    document.getElementById("txtHint").innerHTML ="Coaching id exist" ;
                    document.getElementById("txtHint").style.color ="red" ;  
                    document.getElementById("idcoachingId").style.border  ="4px solid red" ;
                }
                   
               
                    
                   
              
            }
        };
        xmlhttp.open("GET", "uniqueIdCheck.php?q=" + str, true);
        xmlhttp.send();
    }
}