/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


	
             function blockbandschool(thisevalue)
             { 
                 //alert("456"+thisevalue+"789");
                 if(thisevalue!="All")
                 {
                     document.getElementById("idbatch").disabled =false; 
                   document.getElementById("idbatch").style.border="4px solid rosybrown"; 
                   document.getElementById("IdInputSchoolname").disabled =false;
                  document.getElementById("IdInputSchoolname").style.border="4px solid rosybrown";
                     
                         }
              else
                 {
                  document.getElementById("idbatch").disabled =true; 
                   document.getElementById("idbatch").style.border="4px solid green"; 
                   document.getElementById("IdInputSchoolname").disabled =true;
                  document.getElementById("IdInputSchoolname").style.border="4px solid green";
           
                 }
                 
             }
      
     var mobilearray= new Array();  
     var deliveryrrrport="";
     var showflag=0; //0mens show hoi nai ekono
     
                              
                                function smsformat(smsfNumber)
    {
        if(smsfNumber===1)
        {
          var smsformat1="Dear Students: Your class will start from tommorrow,Success+,01726576693";
            document.getElementById('message').value=smsformat1; 
        }
       else if(smsfNumber===2)
        {
          var smsformat2="Dear Students: Tommorrow Coaching will remain closed on account of Bad Weather. Regards,Success+,01726576693";
      document.getElementById('message').value=smsformat2;
        }
        
       else if(smsfNumber===3)
        {
         var smsformat3="Your child ((Student Name))  got ((Obtained Marks)) out of ((Exam Total Marks)) marks in ((Exam Subject Name)),Exam Date:((Exam  Date )),Merit Position:((Merit Position)),GPA-Letter:((Obtained GPA-Letter)),GPA-Point:((Obtained GPA-Point)),Success+,01726576693";
      document.getElementById('message').value=smsformat3; 
        }
       else if(smsfNumber===4)
        {
         var smsformat3="Dear Guardian. Assalamu Alaikum. Your child was absent today. Please sent him/her from tomorrow. Thanks for being with us. Director, Success+";
      document.getElementById('message').value=smsformat3; 
        }
        
         
       
     
      
      
    }
                                function incr(widthincreasby)
    {
       var prevalue=parseInt(document.getElementById('myProgress').value);
       //alert(prevalue);
                document.getElementById('myProgress').value=prevalue+widthincreasby; 
    }
   
          function show()
          {
                   var MESSAGEbOX=document.getElementById('message').value;  
        var MOBILE=document.getElementById('to').value;
           
        
        if(MOBILE=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('to').style.border="2px solid red";  
          document.getElementById('message').style.border="2px solid red";  
        }
        else
        { 
              if(parseInt(showflag)==0)
              {
                    {  
       
       
        var single="";
     //alert(MOBILE.charAt(5));
      document.getElementById("tableshow").style.display = "block";
      document.getElementById("tableshow").style.visibility = "visible";
     var i=0;
     var count=0;
         var table = document.getElementById("tableshow"); 
          
    
                  count++;
        for(i=0;i<MOBILE.length;i++)
        {//alert(MOBILE.charAt(i));
            if(MOBILE.charAt(i).toString()==",")
            {
            // var table = document.getElementById("tableshow");
                      //  alert(single.length);
            if(single.length==0)
            {
                            //alert();  
            }
            else
            {
                    mobilearray.push(single);
                          //  alert(single);
    // setTimeout( cale(single), 2000);
    var row = table.insertRow();
  
                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;
                  single="";
                  count++;
            }
    
              }
              else  if( parseInt(MOBILE.length-1)==i)
            {
            single=single+MOBILE.charAt(i);
            var row = table.insertRow();
          mobilearray.push(single);

                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;
                  single="";
                  count++;
            }
          
            else
            {
              single=single+MOBILE.charAt(i);     
            }
        }
           document.getElementById("tableshow").width="100%";
           showflag=1
    }
              }
              else
              {
                  
              }
          }
          }
      function singleSend()
          { var showflag=0;
                   var MESSAGEbOX=document.getElementById('message').value;  
        var MOBILE=document.getElementById('to').value;
           
        
        if(MOBILE=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('to').style.border="2px solid red";  
          document.getElementById('message').style.border="2px solid red";  
        }
        else
        { 
              if(parseInt(showflag)==0)
              {
                    
       
       
        var single="";
     //alert(MOBILE.charAt(5));
      document.getElementById("tableshow").style.display = "block";
      document.getElementById("tableshow").style.visibility = "visible";
     var i=0;
     var count=0;
         var table = document.getElementById("tableshow"); 
          
    
                  count++;
        for(i=0;i<MOBILE.length;i++)
        {//alert(MOBILE.charAt(i));
            if(MOBILE.charAt(i).toString()==",")
            {
            // var table = document.getElementById("tableshow"); 
               //  alert(single.length);
            if(single.length==0)
            {
                            //alert();  
            }
            else
            {
                    mobilearray.push(single);
                          //  alert(single);
  //  alert( setTimeout( cale(single), 2000));
      setTimeout( cale(single), 2000);
    /*var row = table.insertRow();
  
                var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;*/
                  single="";
                  count++;
            }
              }
              else  if( parseInt(MOBILE.length-1)==i)
            {
            single=single+MOBILE.charAt(i);
         /*   var row = table.insertRow();
          mobilearray.push(single);

                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = count; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = single; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = MESSAGEbOX;
                                  */
                                   setTimeout( cale(single), 2000);
                  single="";
                  count++;
            }
          
            else
            {
              single=single+MOBILE.charAt(i);     
            }
        }
           document.getElementById("tableshow").width="100%";
           showflag=1
    
              }
              else
              {
                  
              }
          }
          }
     
  function testsend()
    {
              var MESSAGEbOX=document.getElementById('message').value;  
        var MOBILE=document.getElementById('to').value;
           
        
        if(MOBILE=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('to').style.border="2px solid red";  
          document.getElementById('message').style.border="2px solid red";  
        }
        else
        { 
         document.getElementById('message').disabled=true;  
        document.getElementById('to').disabled=true; 
        anima( );
      // show();
       disableButton();
     var allm=document.getElementById('to').value;
        document.getElementById('tableshow').style.display="none";
 cale(allm);
 // SoB  ghulo eksathe send hoitace.......................
 
    }

    }
  




 function methodLetterCount( someLetter)
    {
        document.getElementById('idWordCount').innerHTML= someLetter.length;
    }
 function anima( )
    {
       document.getElementById('try').classList.add('container');
       
       document.getElementById('boxid').classList.add('box');
       document.getElementById('borderoneid').classList.add('border');
       document.getElementById('borderoneid').classList.add('one');
       document.getElementById('bordertwo').classList.add('border');
       document.getElementById('bordertwo').classList.add('two');
       document.getElementById('borderthree').classList.add('border');
       document.getElementById('borderthree').classList.add('three');
       document.getElementById('borderfour').classList.add('border');
       document.getElementById('borderfour').classList.add('four');
       document.getElementById('lineone').classList.add('line');
       document.getElementById('lineone').classList.add('one');
       document.getElementById('linetwo').classList.add('line');
       document.getElementById('linetwo').classList.add('two');
       document.getElementById('linethree').classList.add('line');
       document.getElementById('linethree').classList.add('three');
       //document.getElementById('try').style.visibility="visible";
    }
 function animaStop( )
    {   // document.getElementById('some').innerHTML="";  
        document.getElementById('message').value="";  

document.getElementById('to').value="";
       document.getElementById('try').classList.remove('trydancing');
        document.getElementById('try').style.visibility="hidden";
    // location.reload();
    }
 function cale(single)
   { var message=document.getElementById('message').value; 
     // alert(single);
              //  document.getElementById("tableshow").innerHTML="";
           
            var request = new XMLHttpRequest();
           
            request.open('POST', 'requestSendApiBand.php', /* async = */ true);

            var formData = new FormData();
            formData.append('to',single);
            formData.append('message', message);

            request.send(formData);
            request.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {   //alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged);
deliveryrrrport=deliveryrrrport+" \n "+this.responseText;
     document.getElementById('deliveryrrrport').innerHTML=deliveryrrrport;  
           animaStop( );
           
                 
            }
        };
    
              }
 function ResetAll()
    {   document.getElementById('message').disabled=false;  
        document.getElementById('to').disabled=false; 
        mobilearray= new Array();
      //  alert(mobilearray[0]);
       document.getElementById('message').value="";  
        document.getElementById('to').value="";
      
              // document.getElementById('hiddentag').innerHTML="";
               document.getElementById('tableshow').innerHTML="";
                // document.getElementById('hiddentag').style.visibility="hidden";
          document.getElementById('sendsmsid').disabled = false;

          window.location.reload();
    }
    
							
	function disableButton(){
		document.getElementById('sendsmsid').disabled = true;
		//alert("Button has been disabled.");
	}
	function smsBlanceafterSending(){
		 var xmlhttp = new XMLHttpRequest();
             xmlhttp.open("GET", "smsBalanceaftersending.php?", true);
//       
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("balanceAfterSending").innerHTML = this.responseText;
            }
        };
	}

                                                                             
    var allmobileALLCANuSE;
    var allNameALLCANuSE = new Array();
    var allObtainedMarks= new Array();
    var allObtainedgpapoint= new Array();
    var allObtainedgpaGrade= new Array();
    var allObtainedPosition= new Array();
    var allExamTotalMarks= new Array();
    var allExamSubjectname= new Array();
    var allExamDate= new Array();
    var ClassNmae;
    var JSONObject;
      var allMobile=new Array();
    
     function GetInfoTableAndNumber( )
    {   
    
    var classSelected=document.getElementById("idClassSelected").value;
 
    var batchSelected=document.getElementById("idbatch").value;
    
    
    var schoolSelected=document.getElementById("IdInputSchoolname").value;
    
    
  
    
 if (classSelected==="Class Not Selected"   && batchSelected==="Batch Not Selected" && schoolSelected==="School Not Selected") 
 {
        document.getElementById("showlist").innerHTML = " According your search criteria , No student found<br>Please check or change search criteria";
                document.getElementById("idClassSelected").style.border="4px solid Red";
                document.getElementById("idbatch").style.border="4px solid Red";
                //document.getElementById("idgroupid").style.border="4px solid Red";
                document.getElementById("IdInputSchoolname").style.border="4px solid Red";

     
    } else {
          if(classSelected==="Class Not Selected")  
    {      classSelected="";
        document.getElementById("idClassSelected").style.border="4px solid white";
    }
    else {
        document.getElementById("idClassSelected").style.border="4px solid green";
          };
          
   
    
    if(batchSelected=="Batch Not Selected") 
    {      batchSelected="";   
        document.getElementById("idbatch").style.border="4px solid white";
    }
    else 
    {   document.getElementById("idbatch").style.border="4px solid green";
    };
    if(schoolSelected=="School Not Selected")  
    {      schoolSelected="";  
        document.getElementById("IdInputSchoolname").style.border="4px solid white";
    }
    else { 
        document.getElementById("IdInputSchoolname").style.border="4px solid green";}

        var xmlhttp = new XMLHttpRequest();
     
        xmlhttp.open("GET", "requestInformationToSendBatchClassSms.php?class="+classSelected+"&batch="+batchSelected+"&school="+schoolSelected,true);
        
           
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState === 4 && this.status === 200) 
            {
              //  alert(this.responseText);
                //document.getElementById("resultCreateTable").innerHTML = this.responseText;
                 JSONObject = JSON.parse(this.responseText);
               // alert(JSONObject[0].sname);
                 var table = document.getElementById("resultCreateTable");
                 
                for(i=0;i<JSONObject.length ;i++)
                {
                   
  var row = table.insertRow();
  
                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = i+1; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = JSONObject[i].sname; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = JSONObject[i].coachingid;
                  
                  var cell1 = row.insertCell(3);  
                  cell1.innerHTML = JSONObject[i].mobile1; 
                  
                 
                
 
                }
                
               // var myObj =new Array(); 
               // var      
               
              // var JSONObject = JSON.parse(this.responseText);
  //console.log(JSONObject);      // Dump all data of the Object in the console
  //alert(JSONObject[0].mo);
                  //var    myObj= JSON.parse();
                  allmobileALLCANuSE=GetAllMonilenumber(this.responseText);
                  var allmobileOutput="";
                 for(i=0;i<allmobileALLCANuSE.length;i++)
  {
      allmobileOutput=allmobileOutput+","+allmobileALLCANuSE[i];
      
  }
  //alert(allmobileOutput);
  document.getElementById('to').value=allmobileOutput;
                  
       
 
            }
        };
    }
    
      
    }
      
    
   
    function GetAllMonilenumber(array)
    { 
        var JSONObject = JSON.parse(array);
  //console.log(JSONObject);      // Dump all data of the Object in the console
 // var allMobile=new Array();
  //alert(JSONObject.length);
  for(i=0;i<JSONObject.length;i++)
  {
      allMobile.push(JSONObject[i].mobile1);
     // allObtainedMarks.push(JSONObject[i].exammarksttl);
      allObtainedMarks.push(JSONObject[i].ttlmarksobt);
     
      allNameALLCANuSE.push(JSONObject[i].sname);
      //allExamTotalMarks.push(JSONObject[i].exammarksttl);
      //allExamSubjectname.push(JSONObject[i].subname);
     // var examdate= new Date(JSONObject[i].examdate);
      //var examdateWithmonrh=examdate.getDate()+"/"+(parseInt(examdate.getMonth())+1).toString()+"/"+examdate.getFullYear();
     // alert(examdate.getDay());
     //allExamDate.push(examdateWithmonrh);
      //allExamDate.push(JSONObject[i].examdate);
      //alert(JSONObject[i].mobile1);
    // alert(JSONObject[i].ttlmarksobt);
    
   
  }
   return   allMobile;   
    }
  
function showUser()
{

    var classSelected=document.getElementById("idClassSelected").value;
 
    var batchSelected=document.getElementById("idbatch").value;
    
    //var groupSelected=document.getElementById("idgroupid").value;  
    var groupSelected="";  
    var schoolSelected=document.getElementById("IdInputSchoolname").value;
    
    
  
    
 if (classSelected==="Class Not Selected"   && batchSelected==="Batch Not Selected" && schoolSelected==="School Not Selected") 
 {
        document.getElementById("showlist").innerHTML = " According your search criteria , No student found<br>Please check or change search criteria";
                document.getElementById("idClassSelected").style.border="4px solid Red";
                document.getElementById("idbatch").style.border="4px solid Red";
                //document.getElementById("idgroupid").style.border="4px solid Red";
                document.getElementById("IdInputSchoolname").style.border="4px solid Red";

     
    } else {
          if(classSelected==="Class Not Selected")  
    {      classSelected="";
        document.getElementById("idClassSelected").style.border="4px solid white";
    }
    else {
        document.getElementById("idClassSelected").style.border="4px solid green";
          };
          
    if(groupSelected==="Group Search")  
    {      groupSelected=""; 
        //document.getElementById("idgroupid").style.border="4px solid white";
    }
    else {//document.getElementById("idgroupid").style.border="4px solid green";
    };
    
    if(batchSelected=="Batch Not Selected") 
    {      batchSelected="";   
        document.getElementById("idbatch").style.border="4px solid white";
    }
    else 
    {   document.getElementById("idbatch").style.border="4px solid green";
    };
    if(schoolSelected=="School Not Selected")  
    {      schoolSelected="";  
        document.getElementById("IdInputSchoolname").style.border="4px solid white";
    }
    else { 
        document.getElementById("IdInputSchoolname").style.border="4px solid green";};
 
        
        
        
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
               // document.getElementById("txtHint").innerHTML = this.responseText;
                document.getElementById("showlist").innerHTML = this.responseText;
                    }
        };
    //xmlhttp.open("GET","http://ismailbd.rf.gd",true);
       xmlhttp.open("GET","requestToGetMobileIdNameForsms.php?group="+groupSelected+"&class="+classSelected+"&batch="+batchSelected+"&school="+schoolSelected,true);
        xmlhttp.send();
    }
    
    // stop group load
    
      
     
    
    
}


function wait(ms)
{ var d = new Date();
var s = d.getMilliseconds() ;
    var totaltime=parseInt(s)+ms;
    var d2=parseInt(s);
  //  alert(d2);
   // alert(s);
 
    while(d2 <totaltime)
    {
       d2=parseInt(d.getMilliseconds());
       // alert(d2 +"!="+ totaltime) 
    if(d2===totaltime)
    {
            alert();
    }
 
    }
}