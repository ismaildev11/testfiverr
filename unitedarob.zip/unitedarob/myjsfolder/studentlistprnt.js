
   function  printstudentlist(divId,contenthEADHING)
{
    ///time srart
    var atime=new Date();
    var yy=atime.getFullYear();
    var m=atime.getMonth()+1;
    var d=atime.getDate();
    var H=atime.getHours();
    var min=atime.getMinutes();
    var se=atime.getSeconds();
    var ttim= "Printing Date: "+d+"/"+m+"/"+yy+"::"+H+":"+min+":"+se;
   ///time end
   //var heading1="heelo";
   var heading2="<table border=\"0\" cellspacing=\"0\"><tr> <td  rowspan=\"6\" colspan=\"2\" width=\"38%\"  align=\"center\"><span style=\"font-family:Script MT ;color:red;font-size:60px;\">Success+</span><BR><span style=\"font-size:24px;font-family: \"Times New Roman\", Times, serif;\">B-Block,Halishahar,Chattagram <br>01726-576693</span></td></tr></table>";           
var heading="<p align=\"center\"><span style=\"font-family:Script MT ;color:red;font-size:60px;\">Success+</span><BR><span style=\"font-size:24px;font-family: \"Times New Roman\", Times, serif;\">B-Block,Halishahar,Chattagram <br>01726-576693</span></p>";
   var divContents = document.getElementById(divId).innerHTML; 
   //var divId2Content = document.getElementById(divId2).innerHTML; 
            var a = window.open('', '', 'height=1174, width=794'); 
            a.document.write('<html>'); 
            a.document.write('<body style=\"margin:20px;\"><p align=\"right\"><b >'+ttim+'</b></p>'); 
            //a.document.write(divId2Content); 
            var stringcoming='Summery Print';
             a.document.write(heading);   
          //  alert(contenthEADHING);
          /*  if(contenthEADHING.localeCompare(stringcoming))
            {
                
            }
            else
            {
                a.document.write(heading);     
            }*/
        
             a.document.write('<center><h3 >'+contenthEADHING+'</h3></center>'); 

            a.document.write(divContents); 
            a.document.write('</body></html>'); 
      //  a.focus();
  
    //a.print();
  //a.close();   

      a.document.close();
         
           a.print(); 
     //    a.close();  
        
  // return true;    
        
        
        
}
function studentlistpdf(quality = 1) {
		const filename  = 'studentlistpdf.pdf';
//alert();
		html2canvas(document.querySelector('#showlist'), 
								{scale: quality}).then(canvas => {
			let pdf = new jsPDF('p', 'mm', 'a4');
			
			pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, 211, 298);
			pdf.save(filename);
			
		});
	}
	  function studentlistpdfbal() {
        let pdf = new jsPDF('l', 'pt', 'a4');
        pdf.html(document.getElementById('#showlist'), {
            callback: function () {
                pdf.save('test.pdf');
              //  window.open(pdf.output('bloburl')); // to debug
            }
        });
    }
	
  