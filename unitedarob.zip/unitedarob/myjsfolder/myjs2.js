function findexamDATE()
    {
        var classSelected= document.getElementById('classid').value;
        var groupSelected= document.getElementById('idgroupid').value;
        var batchSelected= document.getElementById('batchid').value;
        //alert(classSelected);
      if(classSelected==="Six" || classSelected==="Seven"||classSelected==="Eight" )
    {
         groupSelected = "Not Required"; 
       }
        else
        {
           
        }
        
      
        var condition=" WHERE groupname='"+groupSelected+"' && sectionname='"+batchSelected+"'"
         //alert(condition);
          if (classSelected=="Select Class" && groupSelected=="Select Group") 
    {
        document.getElementById("classid").style.border ="2px solid red";
        document.getElementById("idgroupid").style.border ="2px solid red";
       
    } 
    else
    {
       document.getElementById("classid").style.border ="2px solid green";
        document.getElementById("idgroupid").style.border ="2px solid green";
        var xmlhttp = new XMLHttpRequest();
     
        xmlhttp.open("GET", "getexamdate.php?q="+condition+" &class="+classSelected, true);
        
           
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("examdateshow").innerHTML = this.responseText;
            }
        };  
    }
    }
   function  printmy(divId,contenthEADHING)
{
    ///time srart
    var atime=new Date();
    var yy=atime.getFullYear();
    var m=atime.getMonth()+1;
    var d=atime.getDate();
    var H=atime.getHours();
    var min=atime.getMinutes();
    var se=atime.getSeconds();
    var ttim= "Printing Date: "+d+"/"+m+"/"+yy+"::"+H+":"+min+":"+se;
   ///time end
   
   var divContents = document.getElementById(divId).innerHTML; 
            var a = window.open('', '', 'height=900, width=1500'); 
            a.document.write('<html>'); 
            a.document.write('<body >'+contenthEADHING+";'<b align=\"right\">'"+ttim+"'</b><BR>'"); 
            a.document.write(divContents); 
            a.document.write('</body></html>'); 
      //  a.focus();
  
    //a.print();
  //a.close();  
  a.document.close(); 
         a.print(); 
      //   a.close();  
   // return true;    
        
        
        
}

function presentTimeWithmsH()
{
    var atime=new new Date();
    var yy=atime.getFullYear();
    var m=atime.getMonth();
    var d=atime.getDay();
    return d+"/"+m+"/"+yy;
    
}


        function AllCall()
        {
             balanceTaka();
             tssms();
             esms();
        }
function balanceTaka() {
  
        var xmlhttp = new XMLHttpRequest();
             xmlhttp.open("GET", "http://api.greenweb.com.bd/g_api.php?token=7cbc0a23140cc795a7b32c4bde91af31&balance", true);
//       
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                var smsquantityBalance=Math.floor(parseInt(this.responseText)/.3);
                document.getElementById("balanceId").innerHTML = this.responseText+"BDT "+"/"+smsquantityBalance.toString()+" SMS";
            }
        };
    
}
function tssms() {
  
   
        var xmlhttp = new XMLHttpRequest();
             xmlhttp.open("GET", "http://api.greenweb.com.bd/g_api.php?token=7cbc0a23140cc795a7b32c4bde91af31&totalsms", true);
//       
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("tsId").innerHTML = this.responseText;
            }
        };
   
}
function esms() {
   var xmlhttp = new XMLHttpRequest();
             xmlhttp.open("GET", "http://api.greenweb.com.bd/g_api.php?token=7cbc0a23140cc795a7b32c4bde91af31&expiry", true);
//       
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("eId").innerHTML = this.responseText;
            }
        };
   
}
