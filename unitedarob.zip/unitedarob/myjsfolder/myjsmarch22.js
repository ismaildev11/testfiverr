function findexamDATE()
    {
        var classSelected= document.getElementById('classid').value;
        var groupSelected= document.getElementById('idgroupid').value;
        var batchSelected= document.getElementById('batchid').value;
        //alert(classSelected);
      if(classSelected==="Six" || classSelected==="Seven"||classSelected==="Eight" )
    {
         groupSelected = "Not Required"; 
       }
        else
        {
           
        }
        
      
        var condition=" WHERE groupname='"+groupSelected+"' && sectionname='"+batchSelected+"'"
         //alert(condition);
          if (classSelected=="Select Class" && groupSelected=="Select Group") 
    {
        document.getElementById("classid").style.border ="2px solid red";
        document.getElementById("idgroupid").style.border ="2px solid red";
       
    } 
    else
    {
       document.getElementById("classid").style.border ="2px solid green";
        document.getElementById("idgroupid").style.border ="2px solid green";
        var xmlhttp = new XMLHttpRequest();
     
        xmlhttp.open("GET", "getexamdate.php?q="+condition+" &class="+classSelected, true);
        
           
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("examdateshow").innerHTML = this.responseText;
            }
        };  
    }
    }
   function  printmy(divId,contenthEADHING)
{
    ///time srart
    var atime=new Date();
    var yy=atime.getFullYear();
    var m=atime.getMonth()+1;
    var d=atime.getDate();
    var H=atime.getHours();
    var min=atime.getMinutes();
    var se=atime.getSeconds();
    var ttim= "Printing Date: "+d+"/"+m+"/"+yy+"::"+H+":"+min+":"+se;
   ///time end
   var heading1="heelo";
   var heading="<table><tr> <td  rowspan=\"6\" colspan=\"2\" width=\"38%\"  align=\"center\"><span style=\"font-family:Script MT ;color:red;font-size:60px;\">Success+</span><BR><span style=\"font-size:24px;font-family: \"Times New Roman\", Times, serif;\">B-Block,Halishahar,Chattagram <br>01726-576693</span></td></tr></table>";           

   var divContents = document.getElementById(divId).innerHTML; 
   //var divId2Content = document.getElementById(divId2).innerHTML; 
            var a = window.open('', '', 'height=900, width=1500'); 
            a.document.write('<html>'); 
            a.document.write('<body >'); 
            //a.document.write(divId2Content); 
            a.document.write(heading); 
             a.document.write('<center><h3 >'+contenthEADHING+'</h3><b align=\"right\">'+ttim+'</b></center>'); 

            a.document.write(divContents); 
            a.document.write('</body></html>'); 
      //  a.focus();
  
    //a.print();
  //a.close();  
  a.document.close(); 
         a.print(); 
         a.close();  
   // return true;    
        
        
        
}

function presentTimeWithmsH()
{
    var atime=new new Date();
    var yy=atime.getFullYear();
    var m=atime.getMonth();
    var d=atime.getDay();
    return d+"/"+m+"/"+yy;
    
}


  