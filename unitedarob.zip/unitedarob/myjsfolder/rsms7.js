/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



                                        function stopGropuLoad( classSelected)
                                        {
                                           
                                          /*  if(classSelected==="Six" || classSelected==="Seven"||classSelected==="Eight" )
                                            {
                                             document.getElementById('idgroupid').style.visibility = "hidden"; 
                                            }
                                            else
                                            {
                                              document.getElementById('idgroupid').style.visibility = "visible";   
                                            }*/
                                            var xmlhttp=new XMLHttpRequest();    
                                    xmlhttp.onreadystatechange = function()
                                    {
                                        if (this.readyState == 4 && this.status == 200)
                                        {
                                          document.getElementById("Inputbatchnameexam").innerHTML = this.responseText;
                                         }
                                    };
                                   xmlhttp.open("GET","getbatchOnchange.php?q="+classSelected,true);
                                    xmlhttp.send();
                                        }
                              
                                 
                                                                            
    var allmobileALLCANuSE;
    var allNameALLCANuSE = new Array();
    var allObtainedMarks= new Array();
    var allObtainedgpapoint= new Array();
    var allObtainedgpaGrade= new Array();
    var allObtainedPosition= new Array();
    var allExamTotalMarks= new Array();
    var allExamSubjectname= new Array();
    var allExamDate= new Array();
    var highestmarks=0;
    var ClassNmae;
    var JSONObject;
      var allMobile=new Array();
       var deliveryrrrport="";
      function reset()
      {
          location.reload();
      }
   function show()
    {
         
         
         var MESSAGEbOX=document.getElementById('boxmessage').value;  
         
      var allmobile=document.getElementById('boxAllMobile').value;
        if(allmobile=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('boxAllMobile').style.border="2px solid red";  
          document.getElementById('boxmessage').style.border="2px solid red";  
        }
        else
        {
         var slvalue=1;
            document.getElementById("tableshow").style.display = "block";
        function jsHello(i) {
    if (i < 0) return;
 //var xhr = [];
    setTimeout(function () {
////mystRT
   // alert("Hello " + i);
  var AfterNameChanged= MESSAGEbOX.replace("((Student Name))", allNameALLCANuSE[i]);
   var AfterNameobtMarksChanged= AfterNameChanged.replace("((Obtained Marks))", allObtainedMarks[i]);
   var AfterNameobtMarksttlmrksChanged= AfterNameobtMarksChanged.replace("((Exam Total Marks))", allExamTotalMarks[i]);
   var AfterNameobtMarksttlmrksSBNameChanged= AfterNameobtMarksttlmrksChanged.replace("((Exam Subject Name))", allExamSubjectname[i]);
   var AfterNameobtMarksttlmrksSBNameDateChanged= AfterNameobtMarksttlmrksSBNameChanged.replace("((Exam Date ))", allExamDate[i]);
  // alert(allExamDate[i]);
   var AfterNameobtMarksttlmrksSBNameDateGpChanged= AfterNameobtMarksttlmrksSBNameDateChanged.replace("((Obtained GPA-Letter))", allObtainedgpapoint[i]);
   var AfterNameobtMarksttlmrksSBNameDateGpGLChanged= AfterNameobtMarksttlmrksSBNameDateGpChanged.replace("((Obtained GPA-Point))", allObtainedgpaGrade[i]);
   var AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged= AfterNameobtMarksttlmrksSBNameDateGpGLChanged.replace("((Merit Position))", allObtainedPosition[i]);
    var AfterNameobtMarksttlmrksSBNameDateGpGLPositionHighestMarksChanged= AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged.
    replace("((Highest Marks))", highestmarks);
  //  alert(highestmarks);
  //  alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionHighestMarksChanged);
   
  
   /////start
   var MOBILE=allMobile[i];
   //alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged+","+MOBILE);
      //document.getElementById("tableshow").innerHTML="";
    
         var table = document.getElementById("tableshow"); 
   var row = table.insertRow();
  
                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = slvalue; 
                  slvalue++;
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = MOBILE; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML=AfterNameobtMarksttlmrksSBNameDateGpGLPositionHighestMarksChanged;
                    document.getElementById("tableshow").width="100%";
            jsHello(--i);

    }, 70);
}
jsHello(allmobileALLCANuSE.length-1);
        
    }  
  
   
          
    /*var row1 = table.insertRow();
  
                  var cell1 = row1.insertCell(0);  
                  cell1.innerHTML = "S.L"; 
                  
                  var cell1 = row1.insertCell(1);  
                  cell1.innerHTML = "Mobile"; 
                  
                  var cell1 = row1.insertCell(2);  
                  cell1.innerHTML = "Message";
                  single="+88";
                  count++;*/
      
         
    }
    function showResult( )
    {

        var classSelected= document.getElementById('Inputexamclassname').value;
        ClassNmae=classSelected;
       // var groupSelected= document.getElementById('idgroupid').value;
        var examtype= document.getElementById('InputexamType').value;
        var batchSelected= document.getElementById('Inputbatchnameexam').value;       

        var examdateselected= document.getElementById('Inputexamdate').value;
        var subject= document.getElementById('Inputexamsubject').value;
     //   var exammarks= document.getElementById('Inputexamgmarks').value;
        var examdate=examdateselected;
        //alert();
  
        

        var confirmms="Are you sure to make exam::\n"+"class  ::  "+ classSelected+"\n Batch  ::  "+ batchSelected+"\nExam Type  ::  "+ examtype+"\n Date  ::  "+ examdate+"\nSubject  ::  "+ subject;
        var r = confirm(confirmms);

if(r===true)
{
       
          if (classSelected==="Select Class" && examtype==="Select Exam Type") 
    {
        document.getElementById("Inputexamclassname").style.border ="2px solid red";
        document.getElementById("InputexamType").style.border ="2px solid red";
       
    } 
    else
    {
         //document.getElementById("Inputexamclassname").style.border ="2px solid green";
        //document.getElementById("idgroupid").style.border ="2px solid green";
        
        var xmlhttp = new XMLHttpRequest();
     
        xmlhttp.open("GET", "requestInformationToSendResultSms.php?class="+classSelected+"&batch="+batchSelected+"&examtype="+examtype+"&date="+examdate+"&Inputexamsubject="+subject, true);
        
           
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState === 4 && this.status === 200) 
            {  
                //alert("ki problem");
                highestmarks=0;
                //document.getElementById("resultCreateTable").innerHTML = this.responseText;
                 JSONObject = JSON.parse(this.responseText);
                // alert(JSONObject[0].exammarksttl);
                 var table = document.getElementById("resultCreateTable");
                 
                for(i=0;i<JSONObject.length ;i++)
                {
                   
  var row = table.insertRow();
  
                  var cell1 = row.insertCell(0);  
                  cell1.innerHTML = i+1; 
                  
                  var cell1 = row.insertCell(1);  
                  cell1.innerHTML = JSONObject[i].sname; 
                  
                  var cell1 = row.insertCell(2);  
                  cell1.innerHTML = JSONObject[i].coachingid;
                  
                  var cell1 = row.insertCell(3);  
                  cell1.innerHTML = JSONObject[i].ttlmarksobt; 
                  
                  var cell1 = row.insertCell(4);  
                  cell1.innerHTML = JSONObject[i].position;
                  
                  var cell1 = row.insertCell(5);  
                  cell1.innerHTML = JSONObject[i].gradepoint; 
                  
                  var cell1 = row.insertCell(6);  
                  cell1.innerHTML = JSONObject[i].gradeletter; 
                 var cell1 = row.insertCell(7);  
                  cell1.innerHTML = JSONObject[i].highestm; 
                
                  highestmarks=JSONObject[i].highestm;;
                   // alert(highestmarks);
 
                }
                
               // var myObj =new Array(); 
               // var      
               
              // var JSONObject = JSON.parse(this.responseText);
  //console.log(JSONObject);      // Dump all data of the Object in the console
  //alert(JSONObject[0].mo);
                  //var    myObj= JSON.parse();
                  allmobileALLCANuSE=GetAllMonilenumber(this.responseText);
                  var allmobileOutput="";
                 for(i=0;i<allmobileALLCANuSE.length;i++)
  {
      allmobileOutput=allmobileOutput+";"+allmobileALLCANuSE[i];
      
  }
  //alert(allmobileOutput);
  document.getElementById('boxAllMobile').value=allmobileOutput;
                  
       
 
            }
        };
    }
    
        }
        else
        {
           alert("Ok You donnot want to see"); 
        }
    
    }
    function cale(single)
   { var message=document.getElementById('message').value; 
      
              //  document.getElementById("tableshow").innerHTML="";
           
            var request = new XMLHttpRequest();
           
            request.open('POST', 'requestSendApiBand.php', /* async = */ true);

            var formData = new FormData();
            formData.append('to',single);
            formData.append('message', message);

            request.send(formData);
            request.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {   //alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged);
some=some+" \n "+this.responseText;
     document.getElementById('some').innerHTML=some;  
           
                 
            }
        };
    
              }
    function GetAllMonilenumber(array)
    { 
        var JSONObject = JSON.parse(array);
  //console.log(JSONObject);      // Dump all data of the Object in the console
 // var allMobile=new Array();
  //alert(JSONObject.length);
  for(i=0;i<JSONObject.length;i++)
  {
      allMobile.push(JSONObject[i].mobile1);
     // allObtainedMarks.push(JSONObject[i].exammarksttl);
      allObtainedMarks.push(JSONObject[i].ttlmarksobt);
      allObtainedgpapoint.push(JSONObject[i].gradepoint);
      allObtainedgpaGrade.push(JSONObject[i].gradeletter);
      allObtainedPosition.push(JSONObject[i].position);
      allNameALLCANuSE.push(JSONObject[i].sname);
      allExamTotalMarks.push(JSONObject[i].exammarksttl);
      allExamSubjectname.push(JSONObject[i].subname);
      var examdate= new Date(JSONObject[i].examdate);
      var examdateWithmonrh=examdate.getDate()+"/"+(parseInt(examdate.getMonth())+1).toString()+"/"+examdate.getFullYear();
     // alert(examdate.getDay());
     allExamDate.push(examdateWithmonrh);
      //allExamDate.push(JSONObject[i].examdate);
      //alert(JSONObject[i].mobile1);
    // alert(JSONObject[i].ttlmarksobt);
    
   
  }
   return   allMobile;   
    }
  
    
    function inserting(str)
    {
        var previous=document.getElementById('boxmessage').value;  
        document.getElementById('boxmessage').value=previous+str;  
    }
    function testsend()
    { 
        var MESSAGEbOX=document.getElementById('boxmessage').value;  
         
      var allmobile=document.getElementById('boxAllMobile').value;
        if(allmobile=="" || MESSAGEbOX=="")
        {
           // alert();
          document.getElementById('boxAllMobile').style.border="2px solid red";  
          document.getElementById('boxmessage').style.border="2px solid red";  
        }
        else
        {
                       disableButton();
  anima( );
          document.getElementById('tableshow').style.display="none";

        
        
        function jsHello(i) {
    if (i < 0) return;
 //var xhr = [];
    setTimeout(function () {
////mystRT
  //  alert("Hello " + i);
  var AfterNameChanged= MESSAGEbOX.replace("((Student Name))", allNameALLCANuSE[i]);
   var AfterNameobtMarksChanged= AfterNameChanged.replace("((Obtained Marks))", allObtainedMarks[i]);
   var AfterNameobtMarksttlmrksChanged= AfterNameobtMarksChanged.replace("((Exam Total Marks))", allExamTotalMarks[i]);
   var AfterNameobtMarksttlmrksSBNameChanged= AfterNameobtMarksttlmrksChanged.replace("((Exam Subject Name))", allExamSubjectname[i]);
   
   
   var AfterNameobtMarksttlmrksSBNameDateChanged= AfterNameobtMarksttlmrksSBNameChanged.replace("((Exam Date ))", allExamDate[i]);
   var AfterNameobtMarksttlmrksSBNameDateGpChanged= AfterNameobtMarksttlmrksSBNameDateChanged.replace("((Obtained GPA-Letter))", allObtainedgpapoint[i]);
   var AfterNameobtMarksttlmrksSBNameDateGpGLChanged= AfterNameobtMarksttlmrksSBNameDateGpChanged.replace("((Obtained GPA-Point))", allObtainedgpaGrade[i]);
   var AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged= AfterNameobtMarksttlmrksSBNameDateGpGLChanged.replace("((Merit Position))", allObtainedPosition[i]);
   
   
   var AfterNameobtMarksttlmrksSBNameDateGpGLPositionHighestMarksChanged= AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged.
    replace("((Highest Marks))", highestmarks);
   // alert(highestmarks);
   // alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionHighestMarksChanged);
   
   /////start
   var MOBILE=allMobile[i];
  // alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged+",,"+MOBILE);
   
     var request = new XMLHttpRequest();
           
            request.open('POST', 'requestSendApiBand.php', /* async = */ true);

            var formData = new FormData();
            formData.append('to',MOBILE);
            formData.append('message', AfterNameobtMarksttlmrksSBNameDateGpGLPositionHighestMarksChanged);

            request.send(formData);
            request.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {   //alert(AfterNameobtMarksttlmrksSBNameDateGpGLPositionChanged);
deliveryrrrport=deliveryrrrport+" \n "+this.responseText;
     document.getElementById('deliveryrrrport').innerHTML=deliveryrrrport;  
            smsBlanceafterSending();
            if(i==1){animaStop();}
           
                 
            }
        };
    
            jsHello(--i);

    }, 700);
}
jsHello(allmobileALLCANuSE.length-1);
    }
    }
    
    function disableButton(){
		document.getElementById('sendsmsid').disabled = true;
		//alert("Button has been disabled.");
	}
    function smsformat(smsfNumber)
    {
        if(smsfNumber===1)
        {
          /*  var smsformat1="Your child ((Student Name))  got ((Obtained Marks)),Success+,01726576693 ";*/
           var smsformat1="We have given ((Exam Subject Name)) Exam Khata. Your child ((Student Name)) got ((Obtained Marks)) out of ((Exam Total Marks)). Highest Number ((Highest Marks)). Please check the Exam Khata. Success+, 01726-576693  ";
            document.getElementById('boxmessage').value=smsformat1; 
        }
       else if(smsfNumber===2)
        {
          var smsformat2="We have given ((Exam Subject Name)) Exam Khata. Your child ((Student Name)) got ((Obtained Marks)) out of ((Exam Total Marks)). Exam Date: ((Exam Date )), GPA-Point: ((Obtained GPA-Point)). Highest Number ((Highest Marks)). Please check the Exam Khata. Success+, 01726-576693";
      document.getElementById('boxmessage').value=smsformat2;
        }
        
       else if(smsfNumber===3)
        {
         var smsformat3="Your child ((Student Name))  got ((Obtained Marks)) out of ((Exam Total Marks)) marks in ((Exam Subject Name)),Exam Date:((Exam  Date )),Merit Position:((Merit Position)),GPA-Letter:((Obtained GPA-Letter)),GPA-Point:((Obtained GPA-Point)),Success+,01726576693";
      document.getElementById('boxmessage').value=smsformat3; 
        }
       else if(smsfNumber===4)
        {
         var smsformat3="Your child ((Student Name))  got ((Obtained Marks)) out of ((Exam Total Marks)) marks in ((Exam Subject Name)),Exam Date:((Exam  Date )),Merit Position:((Merit Position)),GPA-Letter:((Obtained GPA-Letter)),GPA-Point:((Obtained GPA-Point)),Success+,01726576693";
      document.getElementById('boxmessage').value=smsformat3; 
        }
        
         
       
     
      
      
    }
    
    function methodLetterCount( someLetter)
    {
        document.getElementById('idWordCount').innerHTML= someLetter.length;
    }
     function anima( )
    {
       document.getElementById('try').classList.add('container');
       
       document.getElementById('boxid').classList.add('box');
       document.getElementById('borderoneid').classList.add('border');
       document.getElementById('borderoneid').classList.add('one');
       document.getElementById('bordertwo').classList.add('border');
       document.getElementById('bordertwo').classList.add('two');
       document.getElementById('borderthree').classList.add('border');
       document.getElementById('borderthree').classList.add('three');
       document.getElementById('borderfour').classList.add('border');
       document.getElementById('borderfour').classList.add('four');
       document.getElementById('lineone').classList.add('line');
       document.getElementById('lineone').classList.add('one');
       document.getElementById('linetwo').classList.add('line');
       document.getElementById('linetwo').classList.add('two');
       document.getElementById('linethree').classList.add('line');
       document.getElementById('linethree').classList.add('three');
       //document.getElementById('try').style.visibility="visible";
    }
 function animaStop( )
    {   // document.getElementById('some').innerHTML="";  
        document.getElementById('boxmessage').value="";  

document.getElementById('boxAllMobile').value="";
       document.getElementById('try').classList.remove('trydancing');
        document.getElementById('try').style.visibility="hidden";
    // location.reload();
    }
    function smsBlanceafterSending(){
		 var xmlhttp = new XMLHttpRequest();
             xmlhttp.open("GET", "smsBalanceaftersending.php?", true);
//       
        xmlhttp.send();
        
        xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
                document.getElementById("balanceAfterSending").innerHTML = this.responseText;
            }
        };
	}
         