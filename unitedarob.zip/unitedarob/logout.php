<?php

session_start();
session_unset();
session_unset(); //unset all session variables
session_destroy();
header("Location: login.php");

