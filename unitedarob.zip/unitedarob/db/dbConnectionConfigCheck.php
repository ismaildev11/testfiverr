<?php




 function OpenMyDbConnection()
 {
  //start here 
// SUUCESS PLUS ONLINE
$ServeName="localhost";
$UserName="root";
$PassWord="";
 
  $myDbName="arobamirat";
 //END HERE
 //

 //END HERE
/*
//start here 
$ServeName="localhost";
$UserName="root";
$PassWord="";
 
  $myDbName="successp_splus";

 //END HERE*/

/*// Create connection
$Connection=new mysqli($ServeName,$UserName,$PassWord);*/
//////......................
//
// Create connection with dbName
$Connection=new mysqli($ServeName,$UserName,$PassWord,$myDbName);

  
// Check connection
if ($Connection->connect_error) 
    {
   die("Connection failed: " . $Connection->connect_error);
   //return "Connection failed: " . $Connection->connect_error;
   // return 0;
    }
else
    {
       // echo "Connected successfully";
       // return "Connected successfully";
        return $Connection;

   }

}

/*
function CloseCon($conn)
 {
 $conn -> close();

  }
   */
  function CloseMyDbConnection($Connection) {
    
      return $Connection->close();
}



