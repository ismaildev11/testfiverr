<?php
///i will not use this page

require './dbConnectionConfigCheck.php';
$dbConection= OpenMyDbConnection();

//check if connection is ok or not
if(is_int($dbConection) && $dbConection== 0)
{
    echo 'Not connected something wrong in db connection page';
}
 else {
    
     echo "step 1:: db connected successfully";
     
                //step two db creation

                // Create database
             $year=date('y');
             $instituteNmae="splus";
             $myDbName=$instituteNmae;
           $sql = "CREATE DATABASE ".$myDbName;
           if ($dbConection->query($sql) === TRUE) {
               echo "step 2 db craetion::Database created successfully";
           } else {
               echo "step 2 db craetion::Error creating database: " . $conn->error;
           }
     
  }
  
