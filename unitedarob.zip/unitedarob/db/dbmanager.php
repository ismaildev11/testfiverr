<?php
require_once './db/dbConnectionConfigCheck.php';
                           ///////////////CREATE..........................
function createTable($sqlstring)
{
     $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";  return "step 1 problem check connection page";
 }
 else 
 {
$sql=$sqlstring;
//echo $sql."</br>";  
$result=mysqli_query($newConnection, $sql)or die(mysqli_error($newConnection));
    
    
    if($result === TRUE)
    {
         CloseMyDbConnection($newConnection); 
        return 1;
        // echo "success";
        
    }
 else {
     $error= $newConnection->error;
     CloseMyDbConnection($newConnection); 
        return $error;
       // echo "step 2 problem".$error;
    }
     
 
     
 }
}
//.....................................INSERT...................................................................

function insertnewEntry($sqlstring)
{
       $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    return "step 1 problem check connection page";
 }
 
 else 
 {
$sql=$sqlstring;//echo $sql."</br>";
    $result=mysqli_query($newConnection, $sql)or die(mysqli_error($newConnection));
       
    if($result === TRUE)
    {
         CloseMyDbConnection($newConnection); 
     //   echo "success";
        return 1;
        
        
    }
 else {
     $error= $newConnection->error;
     CloseMyDbConnection($newConnection); 
        return $error;
       // echo "step 2 problem".$error;
    }
     
 
     
 }


}
//........................................................................................................
//........................................................................................................

function insertnewSchoolName($sqlstring)
{
       $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    return "step 1 problem check connection page";
 }
 else 
 {
$sql=$sqlstring;//echo $sql."</br>";
    $result=mysqli_query($newConnection, $sql)or die(mysqli_error($newConnection));
       
    if($result === TRUE)
    {
         CloseMyDbConnection($newConnection); 
        return 1;
        // echo "success";
        
    }
 else {
     $error= $newConnection->error;
     CloseMyDbConnection($newConnection); 
        return $error;
       // echo "step 2 problem".$error;
    }
     
 
     
 }


}
//........................................................................................................


function selectAllStudent($sqlstring)
{
       $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    return "step 1 problem check connection page";
 }
 else 
 {
$sql=$sqlstring;//echo $sql."</br>";
    $result=mysqli_query($newConnection, $sql)or die(mysqli_error($newConnection));
       //echo $result;
    $test="";
    
   // Numeric array
$row=mysqli_fetch_array($result,MYSQLI_NUM);
     
     CloseMyDbConnection($newConnection); 
        
       // echo "step 2 problem".$error;
    }
     
 return $row;
     
 }
 
 
 
 //8888888888888
 function givestringtoDltRow($createdeleteSqlString) 

 {
       $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    return "step 1 problem check connection page";
 }
 else 
 {
$sql=$createdeleteSqlString;//echo $sql."</br>";
        if ($newConnection->query($sql) === TRUE)

            {
           // echo "Record deleted successfully";
             CloseMyDbConnection($newConnection); 
             return 1;
            } 
        else {
            $error=$newConnection->error;
            
             CloseMyDbConnection($newConnection); 
            echo "Error deleting record: " .$error;
        }

    
        
       // echo "step 2 problem".$error;
    }
     
}




//........................................................................................................
//........................................................................................................

function insertnewbatchName($sqlstring)
{
       $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    return "step 1 problem check connection page";
 }
 else 
 {
$sql=$sqlstring;//echo $sql."</br>";
    $result=mysqli_query($newConnection, $sql)or die(mysqli_error($newConnection));
       
    if($result === TRUE)
    {
         CloseMyDbConnection($newConnection); 
        return 1;
        // echo "success";
        
    }
 else {
     $error= $newConnection->error;
     CloseMyDbConnection($newConnection); 
        return $error;
       // echo "step 2 problem".$error;
    }
     
 
     
 }


}


 function givestringtoDltSectionRow($createdeleteSqlString) 

 {
       $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    return "step 1 problem check connection page";
 }
 else 
 {
$sql=$createdeleteSqlString;//echo $sql."</br>";
        if ($newConnection->query($sql) === TRUE)

            {
            echo "Record deleted successfully";
             CloseMyDbConnection($newConnection); 
             return 1;
            } 
        else {
            $error=$newConnection->error;
            
             CloseMyDbConnection($newConnection); 
            echo "Error deleting record: " .$error;
        }

    
        
       // echo "step 2 problem".$error;
    }
     
}


function showStudentwithClassString($sql)
{
    
     $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    return "step 1 problem check connection page";
     return 0;
 }
 else 
 {
$result = mysqli_query($newConnection,$sql);

  $dbdata = array();


  while ( $row = mysqli_fetch_assoc($result)) 
          {
	$dbdata[]=$row['sname'];
         }
  CloseMyDbConnection($newConnection);
  return $dbdata;
 }
}



function uniqueCheck($sql)
{
        $newConnection=OpenMyDbConnection();
 if(is_int($newConnection) && $newConnection==0)
 {
     echo "step 1 problem check connection page";    
     return "step 1 problem check connection page";
     
 }
 else 
 {
  $result = mysqli_query($newConnection,$sql);
//var_dump($result);
if( mysqli_num_rows($result) >0 )
{ 
    CloseMyDbConnection($newConnection);
   // return "ok its not unique";
    return 0;
    //0 means you canNOT create exam
}
 else {
   CloseMyDbConnection($newConnection);
    return 1; //1 means you can create exam
}
 }
}