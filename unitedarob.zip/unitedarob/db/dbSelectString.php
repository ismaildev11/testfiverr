<?php
function CreateString4selectShowStudent($class)
{
    $year=(string)date("y");
    $TableName=$class.$year;
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createselectSqlString=   "SELECT * FROM ".$TableName;        
            
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createselectSqlString;
    
}