  <?php session_start();
if(!isset($_SESSION['login']))
{
     header("Location: login.php");
}
 else 
     
 {   //echo $_SESSION['login'];
     
 }
?> 
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
   
        <title>Test App Fiverr</title>
       
       <!--link rel="icon" href="./images/logo.ico" type="image/ico" sizes="16x16">.
       <!--fontawesome start-->
       <!script src="https://kit.fontawesome.com/eeaec62120.js"></script>
       <!--fontawesome end-->
       
       
 <!--Offline start-->
       
 <script src="myjsfolder/positioncount.js" type="text/javascript"></script>
  
 <script src="myjsfolder/myjsedit6.js" type="text/javascript"></script>
 <script src="myjsfolder/studentlistprnt.js" type="text/javascript"></script>
   
       <!--online files start-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab&display=swap" rel="stylesheet">
   <!--online files end-->   
 <link href="./mycss/mycss.css" rel="stylesheet" type="text/css"/>
 <link href="./mycss/myresponsive.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  
   <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
 
           
    <style>
        .adminheading
        {
          padding: 5px;
          padding-bottom: 0px;
          background-color: darkgrey;
                      border-bottom: 6px wheat outset;

        }
        
        .adminboxborder
        {
            border: 3px dotted whitesmoke;
            padding: 10px;
            background-color: #7efff5;
        }
        .adminboxborder1
        {
            border: 3px dotted whitesmoke;
            padding: 10px;
            background-color: #7efff5;
            border-bottom: 0px solid transparent;
        }
        .adminboxborder2
        {
            border: 3px dotted whitesmoke;
            padding: 10px;
            background-color: #7efff5;
              border-top: 0px solid transparent;
        }
     .row
{
    margin-left: 1%;
    margin-right: 1%;
}
body
{
    background-color: whitesmoke;
}
table {
  width:100%;
  
  margin: 0 auto;
  font-family:'Open Sans', 'Helvetica', 'Arial';
}

  
  
  
  
  
  
  
  
  
  
  
  
  /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  max-width: 200px ; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
    </style>
   
    
    </head>
    
      <body onload="Load()">
          <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Test App Fiverr</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="./clients.php">All Clients</a></li>
      <li><a href="./addClient.php">Add Clients</a></li>
      <li><a href="./editClient.php">Edit Clients</a></li>
    </ul>
       <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> <?php  echo  $_SESSION['username']; ?></a></li>
      <li><a href="#"> Sign Up</a></li>
      <li><a href="logout.php" class="float-right">Log Out</a></li>
    </ul>
      
  </div>
</nav>
          
         
          <script>
              var oldHistoryid=0;
              
              function afterFive()
  {
      var presenthistoryid;
      var xmlhttp=new XMLHttpRequest();
  
            xmlhttp.onreadystatechange = function() 
        {
            if (this.readyState == 4 && this.status == 200) 
            {
               // document.getElementById("mydashboard").innerHTML = this.responseText;
              var $result=JSON.parse(this.responseText);
              presenthistoryid=$result.historyid;
              var action=$result.actionname;
             // alert(oldHistoryid);
             if(action==="new"){document.getElementById("notification").innerHTML="New Client Added, Click Refresh";}
             if(action==="edit"){document.getElementById("notification").innerHTML="Client Updated, Click Refresh";}
                            if(oldHistoryid===0){   oldHistoryid=presenthistoryid; }
                      else if(oldHistoryid<presenthistoryid){ document.getElementById("myModal").style.display = "block";  oldHistoryid=presenthistoryid;}
                      else{}
            }
        };
    
    xmlhttp.open("GET","checkupdate.php",true);
    xmlhttp.send();
    
   
        
  }
  window.setInterval(afterFive,12000);

    function cancel() {
  document.getElementById("myModal").style.display = "none";
   }  
              
              
              
              
              
      </script>



<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    
    <p id="notification"></p>
    
    <div class="row">
        <div class="col-6 btn btn-success btn-inline"><span class="" onclick="location.reload()">Refresh</span></div>
        <div class="col-6 btn btn-primary btn-inline"><span class="" onclick="cancel()">Cancel</span></div>
    </div>
  </div>

</div>

      