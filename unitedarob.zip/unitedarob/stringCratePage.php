            <?php


 function CreateString4OneClassTable()
{
    $TableName="allstudent";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  
            insertid  INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            coachingid INT(10) UNSIGNED  UNIQUE ,
            sname VARCHAR(50) NOT NULL, gname VARCHAR(50) NOT NULL,            
            mobile1 VARCHAR(17) NOT NULL,   address VARCHAR(80) NOT NULL,            
          schoolnameid INT(5) UNSIGNED,            classn VARCHAR(30) NOT NULL,
                                       
            sectionnameid INT(6) UNSIGNED,     isactive VARCHAR(7) NOT NULL,                                    
            isspecial VARCHAR(7) NOT NULL,  monthlypay INT(6) UNSIGNED NOT NULL  ,    
            admissionpayment INT(6) UNSIGNED NOT NULL, admissiondate DATE NOT NULL,
            activedate DATE NOT NULL,    deactivedate DATE NOT NULL,
                         CONSTRAINT FK_schoolnameid FOREIGN KEY (schoolnameid)
    REFERENCES schoollist(schoolnameid),
              CONSTRAINT FK_sectionnameid FOREIGN KEY (sectionnameid)
    REFERENCES sectionlist(sectionnameid)
             
             
             )";
     
    return $createTableSqlString;
    
}
function CreateString4NewStudentInsert 
($dcoachingid,$dsname ,$dgname ,$dmobile1  ,$daddress ,$dschool ,$classn, $dsectionname ,$disactive ,$disspecial ,$dmonthlypay,$admissionpayment,$dadmissiondate,$activedate )
{ $deactiveDate=date_format(date_create("01-01-2000"),"d/m/y");
    
    $TableName="allstudent";
     $dmonthlypayinteger=(integer)$dmonthlypay;
 $createTableSqlString=           
       "INSERT INTO  ".$TableName.
        " (  coachingid,
sname  ,gname ,mobile1 ,address ,  schoolnameid , classn,sectionnameid ,isactive ,isspecial ,monthlypay ,admissionpayment,admissiondate,activedate,deactivedate  ) VALUES
('$dcoachingid','$dsname' ,'$dgname' ,'$dmobile1'  ,'$daddress' ,'$dschool' , '$classn',   '$dsectionname' ,'$disactive' ,'$disspecial' ,'$dmonthlypayinteger','$admissionpayment' ,'$dadmissiondate','$activedate','$deactiveDate')";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $createTableSqlString; 
    return $createTableSqlString;
    
}
function CreateString4UpdateStudent 
($dcoachingid,$dsname,$dmobile1  ,$dschool  ,$dmonthlypay,$admissionpayment,$BInputclass,$Bidbatch,$newcoachingId )
        
{
   // 
    $TableName="allstudent";
   // $TableName="allstudent";
     $dmonthlypayinteger=(integer)$dmonthlypay;
     $admissionpaymentInteger=(integer)$admissionpayment;
     if($newcoachingId!=$dcoachingid && 0==intval($dschool) )
         {
        
         $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET sname="."'$dsname'".
         ", classn="."'$BInputclass'".
         ", coachingid="."'$newcoachingId'".
         ", sectionnameid="."'$Bidbatch'".
         ", mobile1="."'$dmobile1'" .
      
         ", monthlypay="."'$dmonthlypayinteger'" .
         ", admissionpayment="."'$admissionpaymentInteger'" .
          "   WHERE (  coachingid="."'$dcoachingid'".")";
       }
     elseif($newcoachingId==$dcoachingid && 0==intval($dschool)  )
         {
        
         $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET sname="."'$dsname'".

         ", classn="."'$BInputclass'".
         ", sectionnameid="."'$Bidbatch'".
         ", mobile1="."'$dmobile1'" .
      
         ", monthlypay="."'$dmonthlypayinteger'" .
         ", admissionpayment="."'$admissionpaymentInteger'" .
          "   WHERE (  coachingid="."'$dcoachingid'".")";
       }
       elseif (0==intval($dschool)  )
         {
        
         $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET sname="."'$dsname'".
         ", coachingid="."'$newcoachingId'".

         ", classn="."'$BInputclass'".
         ", sectionnameid="."'$Bidbatch'".
         ", mobile1="."'$dmobile1'" .
      
         ", monthlypay="."'$dmonthlypayinteger'" .
         ", admissionpayment="."'$admissionpaymentInteger'" .
          "   WHERE (  coachingid="."'$dcoachingid'".")";
       }
     elseif( 0!=intval($dschool)) {
 $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET sname="."'$dsname'".
                 ", coachingid="."'$newcoachingId'".

         ", classn="."'$BInputclass'".
         ", sectionnameid="."'$Bidbatch'".
         ", mobile1="."'$dmobile1'" .
         ", schoolnameid="."'$dschool'" .
         ", monthlypay="."'$dmonthlypayinteger'" .
         ", admissionpayment="."'$admissionpayment'" .
                 

          "   WHERE (  coachingid="."'$dcoachingid'".")";
     }
 elseif ( 0==intval($dschool))  {
        
 $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET sname="."'$dsname'".
                  ", coachingid="."'$newcoachingId'".

                ", classn="."'$BInputclass'".
         ", sectionnameid="."'$Bidbatch'".
         ", mobile1="."'$dmobile1'" .
         ", monthlypay="."'$dmonthlypayinteger'" .
         ", admissionpayment="."'$admissionpayment'" .
          "   WHERE (  coachingid="."'$dcoachingid'".")";
   
         
     }
 else {
       $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET sname="."'$dsname'".
                        ", coachingid="."'$newcoachingId'".

                  ", classn="."'$BInputclass'".
         ", sectionnameid="."'$Bidbatch'".
         ", mobile1="."'$dmobile1'" .
         ", schoolnameid="."'$dschool'" .
         ", monthlypay="."'$dmonthlypayinteger'" .
         ", admissionpayment="."'$admissionpayment'" .
          "   WHERE (  coachingid="."'$dcoachingid'".")";  
     }
 
    return $createTableSqlString;
    
}
function createStringActiveChangingClassId 
($oldid,$newid,$oldclass,$newclass,$newbatch,$newmonthly)
{
  //  
    $TableName="allstudent";
    //$TableName="allstudent";
     
      $nowdate=date("Y-m-d");
        
         $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET isactive='Yes' , coachingid="."'$newid'".",  activedate="."'$nowdate'".",  sectionnameid="."'$newbatch'".",   monthlypay="."'$newmonthly'".", classn="."'$newclass'".
  
          "   WHERE (  coachingid="."'$oldid'"."&&  classn="."'$oldclass'".")";
     
    
 
    return $createTableSqlString;
    
}
function CreateString4UpdateStudentActiveDective 
($dcoachingid,$class,$activeOrNot )
{
  //  
    $TableName="allstudent";
    //$TableName="allstudent";
     
      
        
         $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET isactive="."'$activeOrNot'".
  
          "   WHERE (  coachingid="."'$dcoachingid'"."&&  classn="."'$class'".")";
     
    
 
    return $createTableSqlString;
    
}
function deactiveAllByClass 
($class,$activeOrNot )
{
  //  
    $TableName="allstudent";
    //$TableName="allstudent";
     
      
        
         $createTableSqlString=           
       "UPDATE   ".$TableName.
        " SET isactive="."'$activeOrNot'".
  
          "   WHERE (   classn="."'$class'".")";
     
    
 
    return $createTableSqlString;
    
}
            
            
            
            
            
 function CreateString4ClassTable($class)
{
   // 
    $TableName=$class;
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  coachingid INT(10) UNSIGNED  PRIMARY KEY,
            sname VARCHAR(50) NOT NULL,            
            fname VARCHAR(30) NOT NULL,            
            mname VARCHAR(30) NOT NULL,       
            gname VARCHAR(30) NOT NULL,            
            mobile1 VARCHAR(17) NOT NULL,            
                      
            address VARCHAR(80) NOT NULL,            
            school VARCHAR(30) NOT NULL,                        
                                            
            sectionname VARCHAR(20) NOT NULL,                                                 
            isactive VARCHAR(7) NOT NULL,                                    
            isspecial VARCHAR(7) NOT NULL,
            monthlypay INT(5) NOT NULL  ,    
            admissionpayment INT(5) NOT NULL     
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
//start
function CreateNewTable4Allsection()
{
    //
    //$TableName=$class     ;
    $createTableSqlString=
            
            
            "CREATE TABLE sectionTable
         (
            
            sectionid INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            
            sectname VARCHAR(40) NOT NULL
            
            
            
       )";
   // ECHO $year;
   // echo $TableName;
    return $createTableSqlString;
    
}
///end
//
//
//
//
//

//start  .............. Table show string
function CreateString4selectShowStudent($class)
{
    //
    $TableName=$class     ;
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createselectSqlString=   "SELECT * FROM ".$TableName;        
            
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createselectSqlString;
    
}


//
//start  .............. Table create string
function CreateString4schoolNameListTable($TableName)
{
    
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  schoolnameid INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            schoolname VARCHAR(60) UNIQUE NOT NULL          
               
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
///end
//start  .............. Table create string
function CreateString4monthlistTable()
{
    $TableName="monthlist";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  mid INT(3) UNSIGNED  PRIMARY KEY,
            mname VARCHAR(50) UNIQUE NOT NULL          
               
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
///end
//start  .............. Table create string
function CreateString4pAYMENTTable()
{
    $TableName="payment";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  pid INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
           mid INT(3) UNSIGNED,
            advance int NOT NULL,
            due int NOT NULL,
            discount int NOT NULL,
             paymentdate DATE NOT NULL,
insertid INT(10) UNSIGNED,
CONSTRAINT FK_insertid FOREIGN KEY (insertid)
    REFERENCES allstudent(insertid),
    CONSTRAINT FK_mid FOREIGN KEY (mid)
    REFERENCES monthlist(mid)
      
  
            
               
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
///end


/////SELECT payment.coachingid ,sname ,advance,`mid`,mobile1 FROM `payment`,allstudent WHERE payment.coachingid=allstudent.`coachingid`


//start  .............. Table insert string
 function CreateString4NewSchoolNameEntry ($schoolName )
 {   
    $TableName="schoollist"; 
 $insertTableSqlString=           
       "INSERT INTO  ".$TableName.
        " (schoolname) VALUES ('$schoolName' )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}
//start  .............. Table insert string
 function CreateString4NewExpensesEntry ($date,$name,$amount )
 {   
    $TableName="dexpenses"; 
 $insertTableSqlString=           
       "INSERT INTO  ".$TableName.
        " (edate,ename,eamount) VALUES ('$date','$name','$amount' )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}


//start  .............. Table SHOW string
function CreateString4selectShowschoolNameList()
{
     
    $TableName="schoollist";
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createselectSqlString=   "SELECT * FROM ".$TableName;        
       return $createselectSqlString;
    
}
function CreateString4selectBatchNameNameListUnique()
{
     
    $TableName="sectionlist";
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createselectSqlString=   "SELECT DISTINCT sectionname FROM ".$TableName;        
            
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createselectSqlString;
    
}

//start  .............. Table SHOW string
function CreateString4SubjectNameDltRow($SchoolNmaeToDlt)
{
     
    $TableName="subjectlist";
    //"DELETE FROM `subjectlist` WHERE `subjectlist`.`subjectid` = 23"?
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createdeleteSqlString=   "DELETE FROM ".$TableName. " WHERE subjectname="."'$SchoolNmaeToDlt'";        
       // ECHO $createdeleteSqlString;    
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
    require_once './db/dbmanager.php';
    $sendingStringtoManager=givestringtoDltRow($createdeleteSqlString);
    return $sendingStringtoManager;
    
}
//start  .............. Table SHOW string
function CreateString4StudentDltRow($coachingID)
{     require_once './db/dbmanager.php'; 
    $TableName="payment";
        $createdeleteSqlString=   "DELETE FROM ".$TableName. " WHERE coachingid="."'$coachingID'";        

    $sendingStringtoManager=givestringtoDltRow($createdeleteSqlString);
     
    $TableName2="allstudent";
    //"DELETE FROM `subjectlist` WHERE `subjectlist`.`subjectid` = 23"?
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createdeleteSqlString2=   "DELETE FROM ".$TableName2. " WHERE coachingid="."'$coachingID'";        
       // ECHO $createdeleteSqlString;    
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
 
    $sendingStringtoManager2=givestringtoDltRow($createdeleteSqlString2);
   
    return $sendingStringtoManager2;
    
}
//start  .............. Table SHOW string
//start  .............. Table SHOW string
function CreateString4ExamDltRow($Tablename,$subject,$sectionid,$examDate)
{     require_once './db/dbmanager.php'; 
    
        $createdeleteSqlString=  "DELETE FROM ".$Tablename. " WHERE ( sectionnameid="."'$sectionid'"." && subname="."'$subject'"." && examdate="."'$examDate'"."  )";
                   

    //$sendingStringtoManager=givestringtoDltRow($createdeleteSqlString);
     
  
 
    $sendingStringtoManager2=givestringtoDltRow($createdeleteSqlString);
   
   return $sendingStringtoManager2;
    // return $createdeleteSqlString;
    
}
//start  .............. Table SHOW string
function CreateString4SchoolNameDltRow($SchoolNmaeToDlt)
{
     
    $TableName="schoollist";
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createdeleteSqlString=   "DELETE FROM ".$TableName. " WHERE schoolname="."'$SchoolNmaeToDlt'";        
       // ECHO $createdeleteSqlString;    
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
    require_once './db/dbmanager.php';
    $sendingStringtoManager=givestringtoDltRow($createdeleteSqlString);
    return $sendingStringtoManager;
    
}







                                                         ///           section table

//start  .............. Table create string
function CreateString4sectionNameListTable($TableName)
{
    //    $TableName="sectionlist";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  sectionnameid INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            sectionname VARCHAR(50)  NOT NULL ,         
            classname VARCHAR(50)  NOT NULL          
               
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
///end
//start  .............. Table create string
function CreateString4ExpensesTable($TableName)
{
    //    $TableName="sectionlist";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  insid INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            edate  DATE NOT NULL,  
            ename VARCHAR(50)  NOT NULL   ,       
            eamount INT(15) UNSIGNED        
               
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
///end


//start  .............. Table insert string
 function CreateString4sectionNameListEntry ($batchName,$classname )
 {  
    // 
    $TableName="sectionlist";
 $insertTableSqlString=           
       "INSERT INTO  ".$TableName.
        " (sectionname,classname) VALUES ('$batchName','$classname' )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}
//start  .............. Table insert string
 function CreateString4sectionNameListModify ($batchNamenew,$batchNameold,$classname )
 {  
   //  
    $TableName="sectionlist";
 $insertTableSqlString=   
              "UPDATE    ".$TableName." SET  sectionname=  ". "   '$batchNamenew '   ".
        "      WHERE(sectionnameid ='$batchNameold' &&  classname='$classname' )";
      
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}
//start  .............. Table insert string
 function CreateString4schoolNameListModify ($SchoolNameEntryBoxnew,$InputSchoolnameold)
 {  
    // 
    $TableName="schoollist";
 $insertTableSqlString=   
              "UPDATE    ".$TableName." SET  schoolname=  ". "   '$SchoolNameEntryBoxnew '   ".
        "      WHERE(schoolname ='$InputSchoolnameold' )";
      
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}
//start  .............. Table insert string
 function CreateString4ExamCoachingIDModify ($prevoiusID,$NewCoachingID,$BInputclass,$examtype)
 {  
      $classyou= strtolower($BInputclass);
    
      $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    
 $insertTableSqlString=   
              "UPDATE    ".$TableName." SET  coachingid=  ". "   '$NewCoachingID '   ".
        "      WHERE(coachingid ='$prevoiusID' )";
      
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}

//start  .............. Table insert string
 function CreateString4PaymentCoachingIDModify ($prevoiusID,$NewCoachingID)
 {  
    // 
    $TableName="payment";
 $insertTableSqlString=   
              "UPDATE    ".$TableName." SET  coachingid=  ". "   '$NewCoachingID '   ".
        "      WHERE(coachingid ='$prevoiusID' )";
      
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}


//start  .............. Table SHOW string
function CreateString4sectionNameListShows($classNmae)
{
    // 
    $TableName="sectionlist";
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createselectSqlString=   "SELECT DISTINCT sectionname ,sectionnameid FROM ".$TableName." WHERE classname="."'$classNmae'";        
            
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createselectSqlString;
    
}

//start  .............. Table SHOW string
function CreateString4sectionNameListTableDltRow($batchNmaeToDlt)
{
    // 
    $TableName="sectionlist";
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createdeleteSqlString=   "DELETE FROM ".$TableName. " WHERE sectionname ="."'$batchNmaeToDlt'";        
       // ECHO $createdeleteSqlString;    
   // ECHO $year;
   // echo $TableName;
    //coaching id unique   
    require_once './db/dbmanager.php';
    $sendingStringtoManager=givestringtoDltSectionRow($createdeleteSqlString);
    return $sendingStringtoManager;
    
}


//start  .............. Table create string
function CreateString4UserTableCreate()
{
    
    $TableName="userinfo";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  userid INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(20) NOT NULL ,         
            userpass VARCHAR(20) NOT NULL          
               
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
///end

//start  .............. Table insert string
 function CreateString4UserInsert ($USERNAME,$USERPASSWORD )
 {  
     
    $TableName="userinfo";
       
 $insertTableSqlString=           
       "INSERT INTO  ".$TableName."(username, userpass) VALUES ( '$USERNAME', '$USERPASSWORD')";
   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}
//start  .............. Table SHOW string
function CreateString4UserShowCheck($USERNAME,$USERPASSWORD)
{
 
    $TableName="userinfo";
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createselectSqlString=   "SELECT * FROM ".$TableName."  WHERE username='$USERNAME' AND userpass='$USERPASSWORD'"     ;  
            
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
  //  ECHO $createselectSqlString;
    return $createselectSqlString;
    
}
//start  .............. Table create string
function CreateString4SubjectTableCreate()
{
    
    $TableName="subjectlist";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  subjectid INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            subjectname VARCHAR(35) UNIQUE NOT NULL       
               
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
///end

//start  .............. Table insert string
 function CreateString4SubjectInsert ($subjectname )
 {  
     
    $TableName="subjectlist";
       
 $insertTableSqlString=           
       "INSERT INTO  ".$TableName."(subjectname) VALUES ( '$subjectname')";
   
//echo $insertTableSqlString; 
    return $insertTableSqlString;
    
}
//start  .............. Table SHOW string
function CreateString4SubjectShowCheck()
{
 
    $TableName="subjectlist";
    //$createselectSqlString=   "SELECT * FROM ".$TableName. "order by coachingid asc LIMIT 2, 2";        
    $createselectSqlString=   "SELECT * FROM ".$TableName;  
            
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
  //  ECHO $createselectSqlString;
    return $createselectSqlString;
    
}





 function CreateString4ExamresultTablefinal($classyou)
{   $TableName="exam".$classyou."final";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  insertid INT(7) UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
            coachingid INT(10) UNSIGNED NOT NULL,
             mobile1 VARCHAR(17) NOT NULL, 
            sname VARCHAR(50) NOT NULL,            
                                        
            sectionnameid INT(6) UNSIGNED,                subname VARCHAR(30) NOT NULL,
            exammarksttl INT(6) UNSIGNED NOT NULL  ,  cqmarksobt INT(6) UNSIGNED NOT NULL,
            mcqmarksobt INT(6) UNSIGNED NOT NULL,              practicalmarksobt INT(6) UNSIGNED, 
            ttlmarksobt INT(6) UNSIGNED NOT NULL,           examdate DATE NOT NULL,
                       position INT(4) UNSIGNED NOT NULL,              examtype VARCHAR(15) NOT NULL,   
           gradepoint VARCHAR(6)  NOT NULL,            gradeletter VARCHAR(6)  NOT NULL ,
             CONSTRAINT FK_sectionnameidexam".$classyou."final"." FOREIGN KEY (sectionnameid)
    REFERENCES sectionlist(sectionnameid)
           
             
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
 function CreateString4ExamresultTableHalf($classyou)
{   $TableName="exam".$classyou."halfy";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  insertid INT(7) UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
            coachingid INT(10) UNSIGNED NOT NULL,
             mobile1 VARCHAR(17) NOT NULL, 
            sname VARCHAR(50) NOT NULL,            
                                            
            sectionnameid INT(6) UNSIGNED,                subname VARCHAR(30) NOT NULL,
            exammarksttl INT(6) UNSIGNED NOT NULL  ,  cqmarksobt INT(6) UNSIGNED NOT NULL,
            mcqmarksobt INT(6) UNSIGNED NOT NULL,              practicalmarksobt INT(6) UNSIGNED, 
            ttlmarksobt INT(6) UNSIGNED NOT NULL,           examdate DATE NOT NULL,
                       position INT(4) UNSIGNED NOT NULL,              examtype VARCHAR(15) NOT NULL,   
           gradepoint VARCHAR(6)  NOT NULL,            gradeletter VARCHAR(6)  NOT NULL ,
             CONSTRAINT FK_sectionnameidexam".$classyou."halfy"." FOREIGN KEY (sectionnameid)
    REFERENCES sectionlist(sectionnameid)
           
             
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
 function CreateString4ExamresultTable($classyou)
{
    
    $TableName="exam".$classyou;
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " (  insertid INT(7) UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
            coachingid INT(10) UNSIGNED NOT NULL,
             mobile1 VARCHAR(17) NOT NULL, 
            sname VARCHAR(50) NOT NULL,            
                                            
                       sectionnameid INT(6) UNSIGNED,                                                 
               subname VARCHAR(30) NOT NULL,
            exammarksttl INT(6) UNSIGNED NOT NULL  ,  cqmarksobt INT(6) UNSIGNED NOT NULL,
            mcqmarksobt INT(6) UNSIGNED NOT NULL,              practicalmarksobt INT(6) UNSIGNED, 
            ttlmarksobt INT(6) UNSIGNED NOT NULL,            
            examdate DATE NOT NULL,           
           position INT(4) UNSIGNED NOT NULL,              examtype VARCHAR(15) NOT NULL,   
           gradepoint VARCHAR(6)  NOT NULL,            gradeletter VARCHAR(6)  NOT NULL ,
               CONSTRAINT FK_sectionnameidexam".$classyou." FOREIGN KEY (sectionnameid)
    REFERENCES sectionlist(sectionnameid)
                       
             )";
   // ECHO $year;
   // echo $TableName;
    //coaching id unique    
    return $createTableSqlString;
    
}
 function CreateString4ExamSMSAndExamCreateHistoryTable()
{
    
    $TableName="historyexamsmsAll";
    $createTableSqlString=           
            "CREATE TABLE IF NOT EXISTS ".$TableName.
        " ( insertid INT(7) UNSIGNED  AUTO_INCREMENT PRIMARY KEY,            
            classn VARCHAR(15) NOT NULL,                                
            subname VARCHAR(30) NOT NULL,
            exammarksttl INT(6) UNSIGNED NOT NULL  ,            
            examdate DATE NOT NULL,      
            examtype VARCHAR(15) NOT NULL,   
            sectionname VARCHAR(15) NOT NULL,
            smsSendreport VARCHAR(5) NOT NULL
             )";
 
    return $createTableSqlString;
    
}
//start  .............. Table insert string
 function CreateString4smsHistoryEntry ($classname ,$subname ,$exammarksttl,$examdate,$examtype)
 {  
     
    $TableName="historyexamsmsAll";
 $insertTableSqlString=           
       "INSERT INTO  ".$TableName.
        " (classn,subname,exammarksttl,examdate,examtype) VALUES ('$classname','$subname' ,'$exammarksttl','$examdate','$examtype')";

    return $insertTableSqlString;
    
}
 function CreateString4examInsertEntry ($classname ,$subname ,$exammarksttl,$examdate,$examtype)
 {  
    $classyou= strtolower($classname);
    
      $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
 $insertTableSqlString=           
       "INSERT INTO  ".$TableName.
        " (classn,subname,exammarksttl,examdate,examtype) VALUES ('$classname','$subname' ,'$exammarksttl','$examdate','$examtype')";

    return $insertTableSqlString;
    
}

 function CreateString4ExamresultShow($classyou1,$bathname,$examtype,$examdate,$subjectName)
{
     $classyou= strtolower($classyou1);
    
      $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    $createTableSqlString=           
            "SELECT " .$TableName.".* ,sectionlist.* FROM ".$TableName.
        " JOIN `sectionlist` ON (sectionlist.sectionnameid=".$TableName.".sectionnameid) WHERE(" .$TableName.".examtype='$examtype' && " .$TableName.".sectionnameid ='$bathname' && " .$TableName.".examdate='$examdate' && " .$TableName.".subname='$subjectName' )  ORDER BY " .$TableName.".coachingid ASC";
     //echo $createTableSqlString;
    return $createTableSqlString;
    
}
 function CreateString4Examresultcreateupdate($classyou1,$bathname,$examtype,$examdate,$subjectName)
{
     $classyou= strtolower($classyou1);
    
     $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    $createTableSqlString=           
            "SELECT * FROM ".$TableName.
        " WHERE(examtype='$examtype' && sectionnameid ='$bathname' && examdate='$examdate' && subname='$subjectName' )  ORDER BY coachingid ASC";
     //echo $createTableSqlString;
    return $createTableSqlString;
    
}

 function CreateString4ExamresultSelectToShow($classyou1,$bathname,$examtype,$examdate,$subjectName)
{
     $classyou= strtolower($classyou1);
    
        $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    $createTableSqlString=           
            "SELECT *,(SELECT MAX(`ttlmarksobt`) FROM `$TableName` WHERE(examtype='$examtype' && sectionnameid ='$bathname' && examdate='$examdate' && subname='$subjectName' ))  as highestm FROM ".$TableName.
        " WHERE(examtype='$examtype' && sectionnameid ='$bathname' && examdate='$examdate' && subname='$subjectName' )  ORDER BY position ASC";
     //echo $createTableSqlString;
    return $createTableSqlString;
    
}
 function CreateString4ExamresultShowIndividual($classyou1,$id,$examtype)
{
     $classyou= strtolower($classyou1);
    
    $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    $createTableSqlString= 
            "SELECT ".$TableName.".*, sectionlist.sectionname FROM ".$TableName.
        "  JOIN `sectionlist` ON (sectionlist.sectionnameid= ".$TableName.".sectionnameid) WHERE(coachingid='$id' && examtype='$examtype'  )  ORDER BY subname ASC";
     //echo $createTableSqlString;
    return $createTableSqlString;
    
}
 function String4ExamSHOWUpdate($classyou1,$bathnameID,$examdate,$CQMARKS ,$MCQMARKS,$TOTALMARKS,$coachingid,$subname,$practicalMarks,$gpoint,$gletter,$examtype,$mobile1,$sname,$exammarksttl,$position)
{
     $classyou= strtolower($classyou1);
    
    $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    $createTableSqlString=  
                "UPDATE   ".$TableName.
        " SET cqmarksobt="."'$CQMARKS'".
        ",mcqmarksobt="."'$MCQMARKS'".
        ",practicalmarksobt="."'$practicalMarks'".
        ",ttlmarksobt="."'$TOTALMARKS'".
        
         ", gradepoint="."'$gpoint'".
         ", gradeletter="."'$gletter'".
         
       

          "   WHERE (  coachingid="."'$coachingid'"." AND sectionnameid="."'$bathnameID'"." AND subname="."'$subname'"." AND examdate="."'$examdate'"."  )";
            
    
    
    
    return $createTableSqlString;
    
}
 function CreateString4ExamresultcreateupdateEdit($classyou1,$bathnameID,$examdate,$CQMARKS ,$MCQMARKS,$TOTALMARKS,$coachingid,$subname,$practicalMarks,$gpoint,$gletter,$examtype,$mobile1,$sname,$exammarksttl,$position)
{
     $classyou= strtolower($classyou1);
    
    $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    $createTableSqlString=           
            "INSERT INTO    ".$TableName." (  cqmarksobt,mcqmarksobt,ttlmarksobt,practicalmarksobt,gradepoint,gradeletter,sectionnameid,examdate,coachingid,subname,mobile1,sname,exammarksttl,position,examtype)  VALUES ('$CQMARKS'  ,  '$MCQMARKS'  ,'$TOTALMARKS'     ,    '$practicalMarks'    ,      '$gpoint'     ,     \"$gletter\"    ,'$bathnameID' , '$examdate' ,'$coachingid' , '$subname','$mobile1','$sname','$exammarksttl','$position','$examtype')";
    
    return $createTableSqlString;
    
}
 function CreateString4ExamresultcreateupdateEditPosition($classyou1,$bathnameID,$examdate,$marks,$position,$examtype)
{
     $classyou= strtolower($classyou1);
    
     $TableName="";
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    $createTableSqlString=           
            "UPDATE    ".$TableName." SET  position=  ". "   '$position '   ".
        "      WHERE(sectionnameid ='$bathnameID' && examdate='$examdate' && ttlmarksobt='$marks' )";
    
    return $createTableSqlString;
    
}
 function CreateString4ExamresultcreateupdateEditPositionTbName($Batchid,$examSubname,$examDate,$ttlmarks,$position,$TableName)
{
    
    $createTableSqlString=           
            "UPDATE    ".$TableName." SET  position=  ". "   '$position '   ".
        "      WHERE(sectionnameid ='$Batchid' && examdate='$examDate' && subname='$examSubname' && ttlmarksobt='$ttlmarks' )";
    
    return $createTableSqlString;
    
}
//start  .............. Table SHOW string
function CreateString4StudentNameShowOnly($class)
{
      
    $createselectSqlString="SELECT * FROM allstudent WHERE classn="."'$class'";  

    return $createselectSqlString;
    
}
function CreateString4StudentNameShowOnlyDac($class)
{
      
    $createselectSqlString="SELECT * FROM allstudent WHERE ( isactive='No' && classn="."'$class')";  

    return $createselectSqlString;
    
}
function CreateString4StudentNameShowOnlyActive($class)
{
      
    $createselectSqlString="SELECT * FROM allstudent WHERE ( isactive='Yes' && classn="."'$class')";  

    return $createselectSqlString;
    
}


 function CreateString4ExamcreateTableInsert1($classyou1, $sectionname ,  $exammarksttl  , $examdate ,$subname,$examtype)
{  
     $classyou= strtolower($classyou1);
     
$TableName="exam".$classyou;    
    
    $TableName2="allstudent";
    $createTableSqlString= "INSERT INTO  ".$TableName. "  ( sname, coachingid  sectionnameid ,  exammarksttl  ,cqmarksobt,mcqmarksobt,ttlmarksobt,subname ,position,examtype) ( ".
          "( SELECT sname, coachingid , ". 
            " '$sectionname' ,  '$exammarksttl'  ,'0','0','0', '$subname','0' ,"." '$examtype' " .
            " FROM " .$TableName2 ."   WHERE (classn="." '$classyou'    "  ."   '$sectionname'    ". ") ))";   
   
return $createTableSqlString; 
  }
 function CreateString4ExamcreateTableInsert($classyou1 , $sectionname ,  $exammarksttl  , $examdate ,$subname,$examtype)
{  
     $classyou= strtolower($classyou1);
     
$TableName="" ;  
if($examtype=="halfy")
    {  $TableName="exam".$classyou."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$classyou."final";  
  }else{$TableName="exam".$classyou; }
    
    $TableName2="allstudent";
    $createTableSqlString= "INSERT INTO  ".$TableName. "  ( sname, coachingid ,mobile1, sectionnameid ,  exammarksttl  ,cqmarksobt,mcqmarksobt,ttlmarksobt, practicalmarksobt,examdate ,subname ,position,examtype,gradepoint,gradeletter)  ".
          "( SELECT sname, coachingid ,mobile1, ". 
            " '$sectionname' ,  '$exammarksttl'  ,'0','0','0', '0' ,'$examdate','$subname','0' ,'$examtype','0','0'   " .
            " FROM " .$TableName2 ."   WHERE (classn="." '$classyou'"."    && sectionnameid="." '$sectionname'    ". ") )";   

return $createTableSqlString; 
  }
  
  
  
  function createExamNewStudentStringExam($classyou1, $inputexambatch, $Inputexamgmarks, $inputdate, $inputsubject,$examtype)
  
  
  {
         $inputexamclass= strtolower($classyou1);
    $TableName=""  ;

    
    $createSqlString=$sql="SELECT allstudent.* ,sectionlist.sectionname ,sectionlist.sectionnameid FROM allstudent   JOIN `sectionlist` ON (sectionlist.sectionnameid=allstudent.sectionnameid) WHERE ( allstudent.isactive='Yes' && allstudent.classn='$inputexamclass' && sectionlist.sectionnameid='$inputexambatch') ORDER BY allstudent.coachingid ASC";
            
 return $createSqlString;
    }
  function createUniqueCheckStringExam($classyou1, $inputexambatch, $Inputexamgmarks, $inputdate, $inputsubject,$examtype)
  
  
  {
         $inputexamclass= strtolower($classyou1);
    $TableName=""  ;
if($examtype=="halfy")
    {  $TableName="exam".$inputexamclass."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$inputexamclass."final";  
  }else{$TableName="exam".$inputexamclass; }
    
    $createSqlString="SELECT * FROM ".$TableName." WHERE (examdate=". "'$inputdate'"." AND  subname ="."'$inputsubject'"." AND   exammarksttl ="."'$Inputexamgmarks'"." AND sectionnameid = "."'$inputexambatch'"."  ) ORDER BY coachingid ASC "; 
 return $createSqlString;
    }
  function createStringExamSeAlltoUpdate($classyou1, $inputexambatch,  $inputdate, $inputsubject,$examtype)
  
  
  {
         $inputexamclass= strtolower($classyou1);
    $TableName=""  ;
if($examtype=="halfy")
    {  $TableName="exam".$inputexamclass."halfy";  
  }elseif($examtype=="final")
    {  $TableName="exam".$inputexamclass."final";  
  }else{$TableName="exam".$inputexamclass; }
    
    $createSqlString="SELECT ".$TableName.".*, sectionlist.sectionname FROM ".$TableName.
        "  JOIN `sectionlist` ON (sectionlist.sectionnameid= ".$TableName.".sectionnameid) WHERE (".$TableName.".examdate=". "'$inputdate'"." AND  ".$TableName.".subname ="."'$inputsubject'"." AND ".$TableName.".sectionnameid = "."'$inputexambatch'"."  ) ORDER BY coachingid ASC "; 
 return $createSqlString;
    }
  
    
    //new payment insert start
    
     function CreateString4NewPaymentInsertNew($PAYMENTmONTHnAMEAll,$Advance,$DUE,$coachingID,$payDiscount)
{
  
    $TableName="payment";
   // $pdateColoum=strtolower("date".$PAYMENTmONTHnAME);
    $date=date("Y/m/d") ;
    $createTableSqlString=    
            "INSERT INTO  ".$TableName." ( `mid`, `advance`, `due`, `coachingid`,`paymentdate`,`discount`) VALUES ( '$PAYMENTmONTHnAMEAll', '$Advance', '$DUE', '$coachingID','$date','$payDiscount');";
         
       return $createTableSqlString;
    
}
    
    //new payment insert end
    //new payment insert start
    
     function CreateString4NewPaymentFindOID($PAYMENTmONTHnAMEAll,$Advance,$DUE,$coachingID)
{
  
    $TableName="payment";
   // $pdateColoum=strtolower("date".$PAYMENTmONTHnAME);
    $date=date("Y/m/d") ;
    $createTableSqlString=    
            "Select * from  ".$TableName." WHERE( `mid`='$PAYMENTmONTHnAMEAll' &&`coachingid`='$coachingID' && `paymentdate`='$date');";
            
    
    return $createTableSqlString;
    
}
    
    //new payment insert end