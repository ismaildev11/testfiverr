  
    
  
     <?php 
     $id= strval($_GET['id'])  ;    
     
     require './stringCratePage.php';
                                       $string="select * from clients where id=".$id;

                                       require_once './db/dbConnectionConfigCheck.php';
                                       
                                        $newConnection2=OpenMyDbConnection();
                            if(is_int($newConnection2) && $newConnection2==0)
                            {
                                echo "step 1 problem check connection page";    return "step 1 problem check connection page";
                            }
                        else 
                        {
                       $sql=$string;//echo $sql."</br>";
                       
                           $result=mysqli_query($newConnection2, $sql)or die(mysqli_error($newConnection2));
                           // echo $result;
                           $test="";
                           // Numeric array
                           $resultOut=[];
                         while ($row=mysqli_fetch_assoc($result))
                           {
                             
$resultOut['id']=$row['id'];
$resultOut['firstname']=$row['firstname'];
$resultOut['lastname']=$row['lastname'];
$resultOut['phonenumber']=$row['phonenumber'];
                        
                             
                                 
                           
                        }
                           


                           }
                       CloseMyDbConnection($newConnection2);                                    

  echo json_encode($resultOut);
                                      ?>
                                     
 
                                     
                                          
                                        
        
        
       